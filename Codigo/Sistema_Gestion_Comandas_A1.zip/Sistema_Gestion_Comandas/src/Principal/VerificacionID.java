package Principal;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class VerificacionID extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VerificacionID.class.getName());
    
    // Base de datos de usuarios para recuperación
    private static final Map<String, Map<String, String>> USUARIOS_REGISTRADOS = new HashMap<>();
    
    // Usuario encontrado
    private String usuarioEncontrado = "";
    
    static {
        // Configurar usuarios para recuperación de contraseña
        // Estructura: username -> {cedula, fechaNacimiento, colorFavorito}
        
        // Usuario 1: Datos específicos que me diste
        Map<String, String> usuario1 = new HashMap<>();
        usuario1.put("cedula", "0550655559");
        usuario1.put("fechaNacimiento", "30/11/2005");
        usuario1.put("colorFavorito", "negro");
        USUARIOS_REGISTRADOS.put("admin", usuario1);
        
        // Usuario 2: Datos de ejemplo
        Map<String, String> usuario2 = new HashMap<>();
        usuario2.put("cedula", "1234567890");
        usuario2.put("fechaNacimiento", "15/05/1990");
        usuario2.put("colorFavorito", "azul");
        USUARIOS_REGISTRADOS.put("gerente", usuario2);
        
        // Usuario 3: Datos de ejemplo
        Map<String, String> usuario3 = new HashMap<>();
        usuario3.put("cedula", "0987654321");
        usuario3.put("fechaNacimiento", "20/10/1995");
        usuario3.put("colorFavorito", "rojo");
        USUARIOS_REGISTRADOS.put("cajero", usuario3);
    }

    public VerificacionID() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        configurarInterfaz();
    }
    
    private void configurarInterfaz() {
        btnverificaridentidad.setBackground(new Color(121, 0, 209));
        btnverificaridentidad.setForeground(Color.WHITE);
        btnverificaridentidad.setFocusPainted(false);
        btnverificaridentidad.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btncancelar.setBackground(new Color(220, 220, 220));
        btncancelar.setFocusPainted(false);
        btncancelar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        txtcedula.setBorder(BorderFactory.createLineBorder(new Color(121, 0, 209), 1));
        txtfechanacimiento.setBorder(BorderFactory.createLineBorder(new Color(121, 0, 209), 1));
        txtcolof.setBorder(BorderFactory.createLineBorder(new Color(121, 0, 209), 1));
        
        txtfechanacimiento.setToolTipText("Formato: DD/MM/YYYY");
    }
    
    private boolean validarCampos() {
        String cedula = txtcedula.getText().trim();
        String fecha = txtfechanacimiento.getText().trim();
        String color = txtcolof.getText().trim();
        
        if (cedula.isEmpty() || fecha.isEmpty() || color.isEmpty()) {
            mostrarError("⚠️ Todos los campos son obligatorios");
            return false;
        }
        
        if (!cedula.matches("\\d{10}")) {
            mostrarError("❌ Cédula inválida\nDebe tener 10 dígitos numéricos");
            txtcedula.requestFocus();
            return false;
        }
        
        if (!fecha.matches("\\d{2}/\\d{2}/\\d{4}")) {
            mostrarError("❌ Formato de fecha inválido\nUse: DD/MM/YYYY (Ej: 30/11/2005)");
            txtfechanacimiento.requestFocus();
            return false;
        }
        
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);
            Date fechaNac = sdf.parse(fecha);
            
            if (fechaNac.after(new Date())) {
                mostrarError("❌ La fecha no puede ser futura");
                txtfechanacimiento.requestFocus();
                return false;
            }
        } catch (Exception e) {
            mostrarError("❌ Fecha inválida\nEjemplo válido: 30/11/2005");
            txtfechanacimiento.requestFocus();
            return false;
        }
        
        return true;
    }
    
    private boolean buscarUsuarioPorDatos() {
        String cedula = txtcedula.getText().trim();
        String fecha = txtfechanacimiento.getText().trim();
        String color = txtcolof.getText().trim().toLowerCase();
        
        for (Map.Entry<String, Map<String, String>> entry : USUARIOS_REGISTRADOS.entrySet()) {
            Map<String, String> datosUsuario = entry.getValue();
            
            boolean cedulaCoincide = cedula.equals(datosUsuario.get("cedula"));
            boolean fechaCoincide = fecha.equals(datosUsuario.get("fechaNacimiento"));
            boolean colorCoincide = color.equals(datosUsuario.get("colorFavorito").toLowerCase());
            
            if (cedulaCoincide && fechaCoincide && colorCoincide) {
                usuarioEncontrado = entry.getKey();
                return true;
            }
        }
        
        return false;
    }
    
    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this,
            mensaje,
            "Error de validación",
            JOptionPane.ERROR_MESSAGE);
    }
    
    private void mostrarExito(String mensaje) {
        JOptionPane.showMessageDialog(this,
            mensaje,
            "Verificación exitosa",
            JOptionPane.INFORMATION_MESSAGE);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtfechanacimiento = new javax.swing.JTextField();
        txtcedula = new javax.swing.JTextField();
        txtcolof = new javax.swing.JTextField();
        btncancelar = new javax.swing.JToggleButton();
        btnverificaridentidad = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(218, 179, 245));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));

        jLabel1.setBackground(new java.awt.Color(203, 130, 253));
        jLabel1.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Verificación de identidad ___ BRAYMAR RESTAURANTE MARISQUERÍA");

        jLabel2.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        jLabel2.setText("1. ¿Cuál es tu número de cédula?");

        jLabel3.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        jLabel3.setText("2.¿Cuál es tu fecha de nacimiento? (MM/DD/YYYY)");

        jLabel4.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        jLabel4.setText("3.¿Cuál es tu color favorito?");

        txtcedula.addActionListener(this::txtcedulaActionPerformed);

        txtcolof.addActionListener(this::txtcolofActionPerformed);

        btncancelar.setText("Cancelar");
        btncancelar.addActionListener(this::btncancelarActionPerformed);

        btnverificaridentidad.setText("Verificar identidad");
        btnverificaridentidad.addActionListener(this::btnverificaridentidadActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 732, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtcolof, javax.swing.GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE)
                            .addComponent(txtfechanacimiento)
                            .addComponent(txtcedula)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 532, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(284, 284, 284)
                        .addComponent(btncancelar)
                        .addGap(18, 18, 18)
                        .addComponent(btnverificaridentidad)))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel1)
                .addGap(48, 48, 48)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(txtcedula, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(txtfechanacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(txtcolof, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btncancelar)
                    .addComponent(btnverificaridentidad))
                .addContainerGap(72, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtcedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcedulaActionPerformed
        // TODO add your handling code here:
        txtfechanacimiento.requestFocus();
    }//GEN-LAST:event_txtcedulaActionPerformed

    private void txtcolofActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcolofActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcolofActionPerformed

    private void btnverificaridentidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnverificaridentidadActionPerformed
 if (!validarCampos()) {
            return;
        }
        
        if (buscarUsuarioPorDatos()) {
            mostrarExito("✅ Identidad verificada exitosamente\n" +
                        "Usuario: " + usuarioEncontrado + "\n" +
                        "Puede proceder a crear una nueva contraseña");
            
            NuevaContraseña ventanaNuevaContraseña = new NuevaContraseña(usuarioEncontrado);
            ventanaNuevaContraseña.setLocationRelativeTo(null);
            ventanaNuevaContraseña.setVisible(true);
            this.dispose();
        } else {
            mostrarError("❌ Datos incorrectos\n" +
                        "No se encontró ningún usuario con esos datos\n" +
                        "Verifique: Cédula, Fecha de nacimiento y Color favorito");
            
            txtcedula.setText("");
            txtfechanacimiento.setText("");
            txtcolof.setText("");
            txtcedula.requestFocus();
        }
    }//GEN-LAST:event_btnverificaridentidadActionPerformed

    private void btncancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncancelarActionPerformed
        int confirm = JOptionPane.showConfirmDialog(this,
            "¿Cancelar recuperación de contraseña?",
            "Confirmar cancelación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            Login ventanaLogin = new Login();
            ventanaLogin.setLocationRelativeTo(null);
            ventanaLogin.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_btncancelarActionPerformed


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new VerificacionID().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btncancelar;
    private javax.swing.JToggleButton btnverificaridentidad;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtcedula;
    private javax.swing.JTextField txtcolof;
    private javax.swing.JTextField txtfechanacimiento;
    // End of variables declaration//GEN-END:variables
}
