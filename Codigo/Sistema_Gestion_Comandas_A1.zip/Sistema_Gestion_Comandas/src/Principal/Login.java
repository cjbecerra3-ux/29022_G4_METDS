package Principal;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author asus
 */
public class Login extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Login.class.getName());
    
    // Credenciales válidas (public para que NuevaContraseña pueda acceder)
    public static final Map<String, String> USUARIOS_VALIDOS = new HashMap<>();
    
    // Contador de intentos fallidos por usuario
    public static final Map<String, Integer> INTENTOS_FALLIDOS = new HashMap<>();
    
    // Usuarios bloqueados y tiempo de bloqueo
    public static final Map<String, Long> USUARIOS_BLOQUEADOS = new HashMap<>();
    
    // Configuración
    private static final int MAX_INTENTOS = 3;
    private static final int TIEMPO_BLOQUEO_SEGUNDOS = 30;
    
    static {
        // Agrega usuarios válidos (usuario, contraseña)
        USUARIOS_VALIDOS.put("admin", "admin123");
        USUARIOS_VALIDOS.put("gerente", "gerente123");
        USUARIOS_VALIDOS.put("cajero", "cajero123");
        USUARIOS_VALIDOS.put("mesero", "mesero123");
    }

    /**
     * Creates new form Login
     */
    public Login() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Configurar colores
        configurarColores();
    }
    
    private void configurarColores() {
        // Personalizar botón acceder
        btnacceder.setBackground(new Color(121, 0, 209));
        btnacceder.setForeground(Color.WHITE);
        btnacceder.setFocusPainted(false);
        btnacceder.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Personalizar botón olvidar contraseña
        btnolvidarcontra.setForeground(new Color(121, 0, 209));
        btnolvidarcontra.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnolvidarcontra.setBorderPainted(false);
        btnolvidarcontra.setContentAreaFilled(false);
        
        // Personalizar campos de texto
        txtusuario.setBorder(BorderFactory.createLineBorder(new Color(121, 0, 209), 1));
        txtcontraseña.setBorder(BorderFactory.createLineBorder(new Color(121, 0, 209), 1));
        
        // Agregar placeholders
        txtusuario.setToolTipText("Ingrese su nombre de usuario");
        txtcontraseña.setToolTipText("Ingrese su contraseña");
    }
    
    private boolean validarCredenciales(String usuario, String contrasena) {
        // Verificar si el usuario está bloqueado
        if (USUARIOS_BLOQUEADOS.containsKey(usuario)) {
            long tiempoBloqueado = System.currentTimeMillis() - USUARIOS_BLOQUEADOS.get(usuario);
            long segundosBloqueado = tiempoBloqueado / 1000;
            
            if (segundosBloqueado < TIEMPO_BLOQUEO_SEGUNDOS) {
                int segundosRestantes = TIEMPO_BLOQUEO_SEGUNDOS - (int) segundosBloqueado;
                mostrarErrorBloqueo(usuario, segundosRestantes);
                return false;
            } else {
                // Desbloquear usuario
                USUARIOS_BLOQUEADOS.remove(usuario);
                INTENTOS_FALLIDOS.remove(usuario);
            }
        }
        
        // Verificar credenciales
        String contrasenaCorrecta = USUARIOS_VALIDOS.get(usuario);
        
        if (contrasenaCorrecta != null && contrasenaCorrecta.equals(contrasena)) {
            // Login exitoso, reiniciar intentos fallidos
            INTENTOS_FALLIDOS.remove(usuario);
            return true;
        } else {
            // Login fallido
            registrarIntentoFallido(usuario);
            return false;
        }
    }
    
    private void registrarIntentoFallido(String usuario) {
        int intentos = INTENTOS_FALLIDOS.getOrDefault(usuario, 0) + 1;
        INTENTOS_FALLIDOS.put(usuario, intentos);
        
        if (intentos >= MAX_INTENTOS) {
            // Bloquear usuario
            USUARIOS_BLOQUEADOS.put(usuario, System.currentTimeMillis());
            mostrarBloqueoUsuario(usuario);
        } else {
            int intentosRestantes = MAX_INTENTOS - intentos;
            mostrarIntentoFallido(intentosRestantes);
        }
    }
    
    private void mostrarIntentoFallido(int intentosRestantes) {
        JOptionPane.showMessageDialog(this,
            "❌ Usuario o contraseña incorrectos\n" +
            "Intentos restantes: " + intentosRestantes,
            "Error de autenticación",
            JOptionPane.WARNING_MESSAGE);
        
        // Limpiar campo de contraseña
        txtcontraseña.setText("");
        txtcontraseña.requestFocus();
    }
    
    private void mostrarBloqueoUsuario(String usuario) {
        JOptionPane.showMessageDialog(this,
            "🔒 Usuario bloqueado por " + TIEMPO_BLOQUEO_SEGUNDOS + " segundos\n" +
            "Usuario: " + usuario + "\n" +
            "Razón: Demasiados intentos fallidos",
            "Usuario Bloqueado",
            JOptionPane.ERROR_MESSAGE);
        
        // Limpiar campos
        txtusuario.setText("");
        txtcontraseña.setText("");
        txtusuario.requestFocus();
        
        // Deshabilitar botón temporalmente
        btnacceder.setEnabled(false);
        
        // Crear timer para reactivar el botón
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> {
                    btnacceder.setEnabled(true);
                    JOptionPane.showMessageDialog(Login.this,
                        "✅ Usuario desbloqueado\n" +
                        "Puede intentar nuevamente",
                        "Usuario Desbloqueado",
                        JOptionPane.INFORMATION_MESSAGE);
                });
            }
        }, TIEMPO_BLOQUEO_SEGUNDOS * 1000);
    }
    
    private void mostrarErrorBloqueo(String usuario, int segundosRestantes) {
        JOptionPane.showMessageDialog(this,
            "⏳ Usuario temporalmente bloqueado\n" +
            "Usuario: " + usuario + "\n" +
            "Tiempo restante: " + segundosRestantes + " segundos",
            "Acceso Bloqueado",
            JOptionPane.ERROR_MESSAGE);
        
        txtusuario.setText("");
        txtcontraseña.setText("");
        txtusuario.requestFocus();
    }
    
    private void realizarLogin() {
        String usuario = txtusuario.getText().trim();
        String contrasena = new String(txtcontraseña.getPassword()).trim();
        
        // Validar campos vacíos
        if (usuario.isEmpty() || contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "⚠️ Por favor, complete todos los campos",
                "Campos incompletos",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Validar credenciales
        if (validarCredenciales(usuario, contrasena)) {
            // Login exitoso
            JOptionPane.showMessageDialog(this,
                "✅ ¡Bienvenido, " + usuario + "!",
                "Acceso concedido",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Abrir menú principal
            MenuPrincipal MenuInterfaz = new MenuPrincipal();
            MenuInterfaz.setLocationRelativeTo(null);
            MenuInterfaz.setVisible(true);
            this.dispose();
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtusuario = new javax.swing.JTextField();
        txtcontraseña = new javax.swing.JPasswordField();
        btnacceder = new javax.swing.JButton();
        btnolvidarcontra = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));

        jPanel3.setBackground(new java.awt.Color(126, 0, 211));
        jPanel3.setPreferredSize(new java.awt.Dimension(400, 500));
        jPanel3.setLayout(null);

        jLabel1.setBackground(new java.awt.Color(119, 0, 238));
        jLabel1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(121, 0, 209));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("INICIAR SESIÓN");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(121, 0, 209));
        jLabel2.setText("USUARIO");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(121, 0, 209));
        jLabel3.setText("CONTRASEÑA");

        jLabel4.setText("BRAYMAR RESTAURANTE MARISQUERIA");

        txtusuario.addActionListener(this::txtusuarioActionPerformed);

        txtcontraseña.addActionListener(this::txtcontraseñaActionPerformed);

        btnacceder.setBackground(new java.awt.Color(121, 0, 209));
        btnacceder.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnacceder.setForeground(new java.awt.Color(255, 255, 255));
        btnacceder.setText("ACCEDER");
        btnacceder.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnacceder.addActionListener(this::btnaccederActionPerformed);

        btnolvidarcontra.setForeground(new java.awt.Color(121, 0, 209));
        btnolvidarcontra.setText("¿Olvidaste tu contraseña?");
        btnolvidarcontra.addActionListener(this::btnolvidarcontraActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel4)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3)
                                .addComponent(txtusuario)
                                .addComponent(txtcontraseña, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE))
                            .addComponent(jLabel1))
                        .addContainerGap(35, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnacceder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnolvidarcontra, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE))
                        .addGap(50, 50, 50))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(44, 44, 44)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(txtusuario, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(txtcontraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(btnacceder, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnolvidarcontra)
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtusuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtusuarioActionPerformed
        // TODO add your handling code here:
        txtcontraseña.requestFocus();
    }//GEN-LAST:event_txtusuarioActionPerformed

    private void btnaccederActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaccederActionPerformed
        // TODO add your handling code here:sfduudhfouiaebhfoiqwboirg
           realizarLogin();
    }//GEN-LAST:event_btnaccederActionPerformed

    private void btnolvidarcontraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnolvidarcontraActionPerformed
        VerificacionID ventanaVerificacion = new VerificacionID();
        ventanaVerificacion.setLocationRelativeTo(null);
        ventanaVerificacion.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnolvidarcontraActionPerformed

    private void txtcontraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcontraseñaActionPerformed
        // TODO add your handling code here:
        realizarLogin();
    }//GEN-LAST:event_txtcontraseñaActionPerformed
    
    
    private void txtusuarioKeyPressed(java.awt.event.KeyEvent evt) {                                      
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            txtcontraseña.requestFocus();
        }
    }                                     
    
    private void txtcontraseñaKeyPressed(java.awt.event.KeyEvent evt) {                                         
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            realizarLogin();
        }
    }                                        

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            Login login = new Login();
            login.setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnacceder;
    private javax.swing.JButton btnolvidarcontra;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPasswordField txtcontraseña;
    private javax.swing.JTextField txtusuario;
    // End of variables declaration//GEN-END:variables
}
