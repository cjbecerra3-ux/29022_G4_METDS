package Principal;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import Modelo.ComandaData;
import Modelo.ItemComanda;
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class GenerarComandas extends javax.swing.JFrame {
    
    // ========== VARIABLES ==========
    private DefaultTableModel tablaModel;
    private DecimalFormat df = new DecimalFormat("#,##0.00");
    private Map<String, Double> precios = new HashMap<>();
    private Map<String, JLabel> labelsCantidad = new HashMap<>();
    
    // ========== VARIABLES PARA CATEGORÍAS ==========
    private List<Producto> productos = new ArrayList<>();
    private List<Producto> productosActuales = new ArrayList<>();
    private int paginaActual = 0;
    private final int PRODUCTOS_POR_PAGINA = 4;
    
    // ========== LISTA COMPARTIDA DE COMANDA ==========
    public static java.util.List<ComandaData> todasLasComandas = new ArrayList<>();
    private static int contadorId = 0;
    
    // ========== CLASE PARA PRODUCTO ==========
    public static class Producto {
        public int id;
        public String nombre;
        public String descripcion;
        public double precio;
        public String categoria;
        public String emoji;
        
        public Producto(int id, String nombre, String descripcion, double precio, String categoria, String emoji) {
            this.id = id;
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.precio = precio;
            this.categoria = categoria;
            this.emoji = emoji;
        }
    }
    
    // ========== CLASE INTERNA PARA COMANDA ==========
    public static class ComandaData {
        public int id;
        public String cliente;
        public String mesero;
        public java.util.List<String> productos;
        public String estado; // "EN_PROCESO" o "LISTO"
        public String fecha;
        public String hora;
        public Date horaCreacion;
        public Date horaListo;
        public String comentarios;
        public double total;
        
        public ComandaData(int id, String cliente, String mesero, java.util.List<String> productos, 
                          String comentarios, double total) {
            this.id = id;
            this.cliente = cliente;
            this.mesero = mesero;
            this.productos = new ArrayList<>(productos);
            this.estado = "EN_PROCESO";
            this.horaCreacion = new Date();
            
            SimpleDateFormat sdfFecha = new SimpleDateFormat("dd/MM/yyyy");
            SimpleDateFormat sdfHora = new SimpleDateFormat("HH:mm");
            this.fecha = sdfFecha.format(horaCreacion);
            this.hora = sdfHora.format(horaCreacion);
            
            this.comentarios = comentarios;
            this.total = total;
        }
    }
    
    private MenuPrincipal menuPrincipal;

    // ========== CONSTRUCTORES ==========
    public GenerarComandas(MenuPrincipal menuPrincipal) {
        this.menuPrincipal = menuPrincipal;
        initComponents();
        inicializarSistema();
        setLocationRelativeTo(null);
    }
    
    public GenerarComandas() {
        this(null);
    }

    private void inicializarSistema() {
        // 1. Inicializar tabla
        tablaModel = (DefaultTableModel) jTable1.getModel();
        tablaModel.setRowCount(0);
        
        // 2. Inicializar productos
        inicializarProductos();
        
        // 3. Configurar labels de cantidad
        labelsCantidad.put("panel1", jLabel20);
        labelsCantidad.put("panel2", jLabel24);
        labelsCantidad.put("panel3", jLabel28);
        labelsCantidad.put("panel4", jLabel32);
        
        // 4. Mostrar primera categoría
        mostrarCategoria((String)jComboBox1.getSelectedItem());
        
        // 5. INICIALIZAR TOTALES
        lblTotal.setText("S/ 0.00");
        lblNumProductos.setText("0");
    }
    
    private void inicializarProductos() {
        // Ceviches
        productos.add(new Producto(1, "Ceviche Clásico", "Pescado fresco marinado", 25.00, "Ceviches", "🐟"));
        productos.add(new Producto(2, "Ceviche Mixto", "Pescado y mariscos", 32.00, "Ceviches", "🦐"));
        productos.add(new Producto(3, "Ceviche Conchas", "Conchas negras marinadas", 28.00, "Ceviches", "🐚"));
        productos.add(new Producto(4, "Tiradito", "Láminas de pescado", 26.00, "Ceviches", "🍣"));
        
        // Platos Fuertes
        productos.add(new Producto(5, "Arroz Mariscos", "Arroz sauté con mariscos", 30.00, "Platos Fuertes", "🍚"));
        productos.add(new Producto(6, "Chaufa Mariscos", "Arroz frito chino", 28.00, "Platos Fuertes", "🍛"));
        productos.add(new Producto(7, "Parihuela", "Sopa concentrada", 35.00, "Platos Fuertes", "🍲"));
        productos.add(new Producto(8, "Jalea Mixta", "Fritura con yuca", 38.00, "Platos Fuertes", "🍤"));
        
        // Bebidas
        productos.add(new Producto(9, "Chicha Morada", "Bebida de maíz morado", 8.00, "Bebidas", "🍷"));
        productos.add(new Producto(10, "Limonada", "Limonada natural", 7.00, "Bebidas", "🍋"));
        productos.add(new Producto(11, "Inca Kola", "Gaseosa peruana", 6.00, "Bebidas", "🥤"));
        productos.add(new Producto(12, "Cerveza", "Cerveza lager", 12.00, "Bebidas", "🍺"));
        
        // Postres
        productos.add(new Producto(13, "Mazamorra", "Dulce de maíz morado", 10.00, "Postres", "🍮"));
        productos.add(new Producto(14, "Arroz Leche", "Postre cremoso", 9.00, "Postres", "🥣"));
        productos.add(new Producto(15, "Picarones", "Anillos fritos", 12.00, "Postres", "🍩"));
        productos.add(new Producto(16, "Suspiro", "Manjar con merengue", 11.00, "Postres", "🍰"));
        
        // Inicializar precios
        for (Producto p : productos) {
            precios.put(p.nombre, p.precio);
        }
    }
    
    private void mostrarCategoria(String categoria) {
        // Filtrar productos por categoría
        productosActuales.clear();
        for (Producto p : productos) {
            if (p.categoria.equals(categoria)) {
                productosActuales.add(p);
            }
        }
        
        paginaActual = 0;
        mostrarProductosPagina();
    }
    
    private void mostrarProductosPagina() {
        int inicio = paginaActual * PRODUCTOS_POR_PAGINA;
        int fin = Math.min(inicio + PRODUCTOS_POR_PAGINA, productosActuales.size());
        
        // Reiniciar contadores
        jLabel20.setText("0");
        jLabel24.setText("0");
        jLabel28.setText("0");
        jLabel32.setText("0");
        
        // Panel 1
        if (inicio < productosActuales.size()) {
            Producto p1 = productosActuales.get(inicio);
            jLabel17.setText(p1.nombre + " " + p1.emoji);
            jLabel18.setText(p1.descripcion);
            jLabel19.setText("S/ " + df.format(p1.precio));
            jPanel7.setVisible(true);
        } else {
            jPanel7.setVisible(false);
        }
        
        // Panel 2
        if (inicio + 1 < productosActuales.size()) {
            Producto p2 = productosActuales.get(inicio + 1);
            jLabel21.setText(p2.nombre + " " + p2.emoji);
            jLabel22.setText(p2.descripcion);
            jLabel23.setText("S/ " + df.format(p2.precio));
            jPanel8.setVisible(true);
        } else {
            jPanel8.setVisible(false);
        }
        
        // Panel 3
        if (inicio + 2 < productosActuales.size()) {
            Producto p3 = productosActuales.get(inicio + 2);
            jLabel25.setText(p3.nombre + " " + p3.emoji);
            jLabel26.setText(p3.descripcion);
            jLabel27.setText("S/ " + df.format(p3.precio));
            jPanel9.setVisible(true);
        } else {
            jPanel9.setVisible(false);
        }
        
        // Panel 4
        if (inicio + 3 < productosActuales.size()) {
            Producto p4 = productosActuales.get(inicio + 3);
            jLabel29.setText(p4.nombre + " " + p4.emoji);
            jLabel30.setText(p4.descripcion);
            jLabel31.setText("S/ " + df.format(p4.precio));
            jPanel10.setVisible(true);
        } else {
            jPanel10.setVisible(false);
        }
    }
    
    private String obtenerNombreProductoPanel(String panel) {
        int inicio = paginaActual * PRODUCTOS_POR_PAGINA;
        
        switch (panel) {
            case "panel1":
                if (inicio < productosActuales.size()) {
                    return productosActuales.get(inicio).nombre;
                }
                break;
            case "panel2":
                if (inicio + 1 < productosActuales.size()) {
                    return productosActuales.get(inicio + 1).nombre;
                }
                break;
            case "panel3":
                if (inicio + 2 < productosActuales.size()) {
                    return productosActuales.get(inicio + 2).nombre;
                }
                break;
            case "panel4":
                if (inicio + 3 < productosActuales.size()) {
                    return productosActuales.get(inicio + 3).nombre;
                }
                break;
        }
        return "";
    }

    // ========== MÉTODOS PARA GESTIÓN DE CANTIDADES ==========
    private void modificarCantidad(String panelId, int cambio) {
        JLabel label = labelsCantidad.get(panelId);
        if (label == null) return;
        
        String productoNombre = obtenerNombreProductoPanel(panelId);
        if (productoNombre.isEmpty()) return;
        
        int cantidad = Integer.parseInt(label.getText());
        cantidad += cambio;
        if (cantidad < 0) cantidad = 0;
        
        label.setText(String.valueOf(cantidad));
        actualizarTabla(productoNombre, cantidad);
    }

    private void actualizarTabla(String producto, int cantidad) {
        double precio = precios.get(producto);
        double subtotal = precio * cantidad;
        
        // Buscar producto en tabla
        for (int i = 0; i < tablaModel.getRowCount(); i++) {
            if (tablaModel.getValueAt(i, 0).equals(producto)) {
                if (cantidad == 0) {
                    tablaModel.removeRow(i);
                } else {
                    tablaModel.setValueAt(cantidad, i, 2);
                    tablaModel.setValueAt("S/ " + df.format(subtotal), i, 3);
                }
                calcularTotales();
                return;
            }
        }
        
        // Si no existe y cantidad > 0, agregar
        if (cantidad > 0) {
            tablaModel.addRow(new Object[]{
                producto,
                "S/ " + df.format(precio),
                cantidad,
                "S/ " + df.format(subtotal)
            });
            calcularTotales();
        }
    }

    private void calcularTotales() {
        double total = 0;
        int totalProductos = 0;
        
        for (int i = 0; i < tablaModel.getRowCount(); i++) {
            try {
                String subtotalStr = tablaModel.getValueAt(i, 3).toString()
                    .replace("S/", "").replace(" ", "").replace(",", "").trim();
                total += Double.parseDouble(subtotalStr);
                
                String cantidadStr = tablaModel.getValueAt(i, 2).toString();
                totalProductos += Integer.parseInt(cantidadStr);
            } catch (Exception e) {
                // Ignorar
            }
        }
        
        lblTotal.setText("S/ " + df.format(total));
        lblNumProductos.setText(String.valueOf(totalProductos));
    }

    // ========== MÉTODOS DE ACCIÓN ==========
    private void limpiarTodo() {
        tablaModel.setRowCount(0);
        jLabel20.setText("0");
        jLabel24.setText("0");
        jLabel28.setText("0");
        jLabel32.setText("0");
        txtCliente.setText("");
        txtComentarios.setText("");
        lblTotal.setText("S/ 0.00");
        lblNumProductos.setText("0");
    }

    private void confirmarPedido() {
        if (tablaModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, 
                "❌ Agregue productos al pedido", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String cliente = txtCliente.getText().trim();
        if (cliente.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "❌ Ingrese nombre del cliente", 
                "Error", JOptionPane.ERROR_MESSAGE);
            txtCliente.requestFocus();
            return;
        }
        
        // 1. Recoger productos
        java.util.List<String> productosPedido = new ArrayList<>();
        StringBuilder detalleProductos = new StringBuilder();
        int totalUnidades = 0;
        
        for (int i = 0; i < tablaModel.getRowCount(); i++) {
            String producto = tablaModel.getValueAt(i, 0).toString();
            int cantidad = Integer.parseInt(tablaModel.getValueAt(i, 2).toString());
            String precioUnitario = tablaModel.getValueAt(i, 1).toString();
            String subtotal = tablaModel.getValueAt(i, 3).toString();
            
            productosPedido.add(cantidad + "x " + producto);
            totalUnidades += cantidad;
            
            // Formato para cada producto
            detalleProductos.append("<tr>")
                           .append("<td style='padding: 5px 0; border-bottom: 1px solid #f0f0f0;'>").append(producto).append("</td>")
                           .append("<td style='padding: 5px 10px; text-align: center; border-bottom: 1px solid #f0f0f0;'>").append(cantidad).append("</td>")
                           .append("<td style='padding: 5px 10px; text-align: right; border-bottom: 1px solid #f0f0f0;'>").append(precioUnitario).append("</td>")
                           .append("<td style='padding: 5px 10px; text-align: right; border-bottom: 1px solid #f0f0f0; font-weight: bold;'>").append(subtotal).append("</td>")
                           .append("</tr>");
        }
        
        // 2. Calcular total
        double total = 0;
        try {
            String totalStr = lblTotal.getText().replace("S/", "").replace(" ", "").replace(",", "").trim();
            total = Double.parseDouble(totalStr);
        } catch (Exception e) {
            total = 0;
        }
        
        // 3. Generar ID ÚNICO desde MongoDB - ¡PARTE CRÍTICA ARREGLADA!
        int nuevoId = 0;
        try {
            // Intentar obtener ID único desde MongoDB
            nuevoId = ConexionMongoDB.obtenerSiguienteId();
            System.out.println("✅ ID generado desde MongoDB: " + nuevoId);
        } catch (Exception e) {
            // Fallback: usar timestamp como ID único
            System.err.println("⚠️ Error obteniendo ID de MongoDB: " + e.getMessage());
            nuevoId = (int) (System.currentTimeMillis() % 100000) + 1000;
            System.out.println("📝 Usando ID temporal único: " + nuevoId);
        }

        // Asegurar que el ID sea positivo
        if (nuevoId <= 0) {
            nuevoId = Math.abs((int) System.currentTimeMillis() % 100000) + 1000;
        }
        
        // 4. Crear nueva comanda
        GenerarComandas.ComandaData nuevaComanda = new GenerarComandas.ComandaData(
            nuevoId,
            cliente,
            "MESERO-01",
            productosPedido,
            txtComentarios.getText(),
            total
        );
        
        // 5. Guardar en MongoDB
        try {
            ConexionMongoDB.guardarComanda(nuevaComanda);
            System.out.println("✅ Comanda #" + nuevoId + " guardada en MongoDB");
            System.out.println("📊 Cliente: " + cliente + ", Total: S/" + total);
        } catch (Exception e) {
            System.err.println("⚠️ No se pudo guardar en MongoDB: " + e.getMessage());
        }
        
        // 6. Agregar a lista local
        todasLasComandas.add(nuevaComanda);
        
        // 7. Mostrar confirmación
        String mensaje = "<html>"
            + "<div style='font-family: Segoe UI, Arial, sans-serif; font-size: 11px; max-width: 400px; text-align: center;'>"
            + "<div style='margin-bottom: 20px;'>"
            + "<div style='color: #27ae60; font-size: 20px; margin-bottom: 5px;'>✓</div>"
            + "<div style='color: #2c3e50; font-size: 13px; font-weight: 600; margin-bottom: 3px;'>Comanda Confirmada</div>"
            + "<div style='color: #7f8c8d; font-size: 10px;'>Pedido registrado exitosamente</div>"
            + "</div>"
            + "<div style='background-color: #f8f9fa; padding: 12px; border-radius: 6px; margin-bottom: 15px; text-align: left;'>"
            + "<table style='width: 100%; border-collapse: collapse;'>"
            + "<tr><td style='padding: 4px 0; width: 90px; color: #5d6d7e; font-weight: 500;'>N° Comanda:</td><td style='padding: 4px 0; font-weight: 600;'>#" + nuevoId + "</td></tr>"
            + "<tr><td style='padding: 4px 0; color: #5d6d7e; font-weight: 500;'>Cliente:</td><td style='padding: 4px 0;'>" + cliente + "</td></tr>"
            + "<tr><td style='padding: 4px 0; color: #5d6d7e; font-weight: 500;'>Mesero:</td><td style='padding: 4px 0;'>MESERO-01</td></tr>"
            + "</table>"
            + "</div>"
            + "<div style='margin: 15px 0 10px 0; color: #34495e; font-weight: 600; font-size: 12px; text-align: left;'>"
            + "📦 Productos Pedidos"
            + "</div>"
            + "<div style='overflow-x: auto; margin-bottom: 15px;'>"
            + "<table style='width: 100%; border-collapse: collapse; font-size: 10.5px; border: 1px solid #e0e0e0; border-radius: 4px;'>"
            + "<thead style='background-color: #f2f3f4;'>"
            + "<tr>"
            + "<th style='padding: 8px 10px; text-align: left; font-weight: 600; color: #5d6d7e; border-bottom: 1px solid #e0e0e0;'>Producto</th>"
            + "<th style='padding: 8px 10px; text-align: center; font-weight: 600; color: #5d6d7e; border-bottom: 1px solid #e0e0e0;'>Cant</th>"
            + "<th style='padding: 8px 10px; text-align: right; font-weight: 600; color: #5d6d7e; border-bottom: 1px solid #e0e0e0;'>P. Unitario</th>"
            + "<th style='padding: 8px 10px; text-align: right; font-weight: 600; color: #5d6d7e; border-bottom: 1px solid #e0e0e0;'>Subtotal</th>"
            + "</tr>"
            + "</thead>"
            + "<tbody>"
            + detalleProductos.toString()
            + "</tbody>"
            + "</table>"
            + "</div>"
            + "<div style='background-color: #f8f9fa; padding: 12px; border-radius: 6px; margin-bottom: 15px;'>"
            + "<table style='width: 100%; border-collapse: collapse;'>"
            + "<tr>"
            + "<td style='padding: 4px 0; color: #5d6d7e;'>Total Productos:</td>"
            + "<td style='padding: 4px 0; text-align: right; font-weight: 600;'>" + tablaModel.getRowCount() + "</td>"
            + "</tr>"
            + "<tr>"
            + "<td style='padding: 4px 0; color: #5d6d7e;'>Total Unidades:</td>"
            + "<td style='padding: 4px 0; text-align: right; font-weight: 600;'>" + totalUnidades + "</td>"
            + "</tr>"
            + "</table>"
            + "</div>"
            + "<div style='background-color: #e8f5e9; padding: 12px; border-radius: 6px; border: 1px solid #c8e6c9; margin-bottom: 15px;'>"
            + "<div style='display: flex; justify-content: space-between; align-items: center;'>"
            + "<div style='color: #27ae60; font-weight: 600; font-size: 12px;'>TOTAL A PAGAR:</div>"
            + "<div style='color: #27ae60; font-weight: 700; font-size: 14px;'>S/ " + String.format("%.2f", total) + "</div>"
            + "</div>"
            + "</div>"
            + "<div style='color: #95a5a6; font-size: 9px; padding-top: 10px; border-top: 1px solid #ecf0f1; text-align: center; line-height: 1.4;'>"
            + "✅ La comanda ha sido enviada a cocina<br>"
            + "<span style='color: #7f8c8d;'>Puede verla en 'Visualizar Comandas'</span>"
            + "</div>"
            + "</div>"
            + "</html>";
        
        JTextPane textPane = new JTextPane();
        textPane.setContentType("text/html");
        textPane.setText(mensaje);
        textPane.setEditable(false);
        textPane.setBackground(Color.WHITE);
        textPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JScrollPane scrollPane = new JScrollPane(textPane);
        scrollPane.setPreferredSize(new Dimension(420, 450));
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        JOptionPane.showMessageDialog(this, scrollPane, 
            "Comanda #" + nuevoId, JOptionPane.INFORMATION_MESSAGE);
        
        // 8. Limpiar para nuevo pedido
        limpiarTodo();
    }
    
    // ========== REGRESAR AL MENÚ ==========
    private void regresarAlMenu() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "¿Regresar al menú principal?\nLos cambios no guardados se perderán.",
            "Confirmar Regreso",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            if (menuPrincipal != null) {
                menuPrincipal.setVisible(true);
                menuPrincipal.setLocationRelativeTo(null);
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel7 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jLabel32 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        lblNumProductos = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        lblTotal = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtComentarios = new javax.swing.JTextArea();
        txtCliente = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnregresar = new javax.swing.JButton();
        btnlimpiar = new javax.swing.JButton();
        btnconfirmar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jSplitPane1.setDividerLocation(800);

        jPanel1.setBackground(new java.awt.Color(126, 0, 211));

        jLabel1.setText("jLabel1");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ceviches", "Platos Fuertes", "Bebidas", "Postres" }));
        jComboBox1.addActionListener(this::jComboBox1ActionPerformed);

        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jPanel7.setPreferredSize(new java.awt.Dimension(300, 150));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel17.setText("Tiradito");
        jPanel7.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        jLabel18.setText("Láminas de pescado fresco");
        jPanel7.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        jLabel19.setText("S/ 26.00");
        jPanel7.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        jButton5.setText("-");
        jButton5.addActionListener(this::jButton5ActionPerformed);
        jPanel7.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, -1, -1));

        jLabel20.setText("0");
        jPanel7.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 166, 20, 30));

        jButton6.setText("+");
        jButton6.addActionListener(this::jButton6ActionPerformed);
        jPanel7.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, -1, -1));

        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jPanel8.setPreferredSize(new java.awt.Dimension(300, 150));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel21.setText("Tiradito");
        jPanel8.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        jLabel22.setText("Láminas de pescado fresco");
        jPanel8.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        jLabel23.setText("S/ 26.00");
        jPanel8.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        jButton7.setText("-");
        jButton7.addActionListener(this::jButton7ActionPerformed);
        jPanel8.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, -1, -1));

        jLabel24.setText("0");
        jPanel8.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 166, 10, 30));

        jButton8.setText("+");
        jButton8.addActionListener(this::jButton8ActionPerformed);
        jPanel8.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, -1, -1));

        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jPanel9.setPreferredSize(new java.awt.Dimension(300, 150));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel25.setText("Tiradito");
        jPanel9.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        jLabel26.setText("Láminas de pescado fresco");
        jPanel9.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        jLabel27.setText("S/ 26.00");
        jPanel9.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        jButton9.setText("-");
        jButton9.addActionListener(this::jButton9ActionPerformed);
        jPanel9.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, -1, -1));

        jLabel28.setText("0");
        jPanel9.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 166, 10, 30));

        jButton10.setText("+");
        jButton10.addActionListener(this::jButton10ActionPerformed);
        jPanel9.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, -1, -1));

        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jPanel10.setPreferredSize(new java.awt.Dimension(300, 150));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel29.setText("Tiradito");
        jPanel10.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        jLabel30.setText("Láminas de pescado fresco");
        jPanel10.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        jLabel31.setText("S/ 26.00");
        jPanel10.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        jButton11.setText("-");
        jButton11.addActionListener(this::jButton11ActionPerformed);
        jPanel10.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, -1, -1));

        jLabel32.setText("0");
        jPanel10.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 166, 10, 30));

        jButton12.setText("+");
        jButton12.addActionListener(this::jButton12ActionPerformed);
        jPanel10.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, -1, -1));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(39, 39, 39)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(63, 63, 63)
                            .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 60, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jComboBox1.getAccessibleContext().setAccessibleName("comboCategoria");

        jSplitPane1.setLeftComponent(jPanel1);

        jLabel5.setText("RESUMEN DEL PEDIDO");

        jPanel5.setBackground(new java.awt.Color(204, 255, 255));

        jLabel6.setText("PRODUCTOS");

        lblNumProductos.setText("0");

        jLabel8.setText("productos");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(54, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblNumProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(47, 47, 47))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblNumProductos)
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(204, 204, 255));

        jLabel9.setText("TOTAL");

        lblTotal.setText("S/ 0.00");

        jLabel11.setText("importe total");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addGap(40, 40, 40))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addComponent(lblTotal)
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txtComentarios.setColumns(20);
        txtComentarios.setRows(5);
        jScrollPane1.setViewportView(txtComentarios);
        txtComentarios.getAccessibleContext().setAccessibleName("");

        jLabel7.setText("Cliente:");

        jLabel10.setText("Comentarios:");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Producto", "Precio", "Cantidad", "Subtotal"
            }
        ));
        jScrollPane3.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(250);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(100);
            jTable1.getColumnModel().getColumn(2).setPreferredWidth(180);
            jTable1.getColumnModel().getColumn(3).setPreferredWidth(120);
        }

        btnregresar.setText("Regresar");
        btnregresar.addActionListener(this::btnregresarActionPerformed);

        btnlimpiar.setText("Limpiar");
        btnlimpiar.addActionListener(this::btnlimpiarActionPerformed);

        btnconfirmar.setText("Confirmar");
        btnconfirmar.addActionListener(this::btnconfirmarActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel5))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnregresar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnlimpiar)
                                .addGap(41, 41, 41)
                                .addComponent(btnconfirmar))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(14, 14, 14))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel10)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(36, 36, 36)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnregresar)
                    .addComponent(btnlimpiar)
                    .addComponent(btnconfirmar))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        jSplitPane1.setRightComponent(jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane1)
        );

        jSplitPane1.getAccessibleContext().setAccessibleName("splitpane");

        pack();
    }// </editor-fold>//GEN-END:initComponents
 
    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed

        modificarCantidad("panel4", -1);
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
 
        modificarCantidad("panel3", -1);
    }//GEN-LAST:event_jButton9ActionPerformed
        
    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
       
        modificarCantidad("panel2", -1);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        modificarCantidad("panel1", -1);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        String categoriaSeleccionada = (String) jComboBox1.getSelectedItem();
        mostrarCategoria(categoriaSeleccionada);
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed

        modificarCantidad("panel4", 1);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
       
        modificarCantidad("panel3", 1);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        
        modificarCantidad("panel2", 1);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
     
        modificarCantidad("panel1", 1);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void btnregresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnregresarActionPerformed
        regresarAlMenu();
    }//GEN-LAST:event_btnregresarActionPerformed

    private void btnlimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimpiarActionPerformed
        limpiarTodo();
    }//GEN-LAST:event_btnlimpiarActionPerformed

    private void btnconfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnconfirmarActionPerformed
        // TODO add your handling code here:
        confirmarPedido();
    }//GEN-LAST:event_btnconfirmarActionPerformed

        public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {}
        
        java.awt.EventQueue.invokeLater(() -> {
            new GenerarComandas().setVisible(true);
        });
    }
        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnconfirmar;
    private javax.swing.JButton btnlimpiar;
    private javax.swing.JButton btnregresar;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblNumProductos;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JTextField txtCliente;
    private javax.swing.JTextArea txtComentarios;
    // End of variables declaration//GEN-END:variables
}
