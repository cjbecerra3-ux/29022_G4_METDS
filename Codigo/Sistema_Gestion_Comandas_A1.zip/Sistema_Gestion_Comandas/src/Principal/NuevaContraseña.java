package Principal;

import javax.swing.*;
import java.awt.*;

public class NuevaContraseña extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(NuevaContraseña.class.getName());
    
    // Usuario que está recuperando la contraseña
    private String usuario;
    
    public NuevaContraseña(String usuario) {
        this.usuario = usuario;
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        configurarInterfaz();
        
        // Mostrar usuario en el título
        setTitle("Nueva contraseña para: " + usuario + " - BRAYMAR RESTAURANTE");
    }
    
    public NuevaContraseña() {
        this("Usuario");
    }
    
    private void configurarInterfaz() {
        // Configurar botones
        btnconfirmar.setBackground(new Color(121, 0, 209));
        btnconfirmar.setForeground(Color.WHITE);
        btnconfirmar.setFocusPainted(false);
        btnconfirmar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btncancelar2.setBackground(new Color(220, 220, 220));
        btncancelar2.setFocusPainted(false);
        btncancelar2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Configurar campos de contraseña
        jPasswordField3.setBorder(BorderFactory.createLineBorder(new Color(121, 0, 209), 1));
        jPasswordField1.setBorder(BorderFactory.createLineBorder(new Color(121, 0, 209), 1));
    }
    
    private boolean validarContraseña() {
        String nuevaContraseña = new String(jPasswordField3.getPassword());  // ← CAMBIADO
        String confirmarContraseña = new String(jPasswordField1.getPassword()); // ← CAMBIADO
        
        // Validar campos vacíos
        if (nuevaContraseña.isEmpty() || confirmarContraseña.isEmpty()) {
            mostrarError("⚠️ Ambas contraseñas son obligatorias");
            return false;
        }
        
        // Validar longitud mínima
        if (nuevaContraseña.length() < 6) {
            mostrarError("❌ La contraseña debe tener al menos 6 caracteres");
            jPasswordField3.requestFocus();  // ← CAMBIADO
            return false;
        }
        
        // Validar que coincidan
        if (!nuevaContraseña.equals(confirmarContraseña)) {
            mostrarError("❌ Las contraseñas no coinciden\n" +
                        "Por favor, ingrese la misma contraseña en ambos campos");
            jPasswordField1.requestFocus();  // ← CAMBIADO
            return false;
        }
        
        return true;
    }
    
    private void actualizarContraseñaEnLogin() {
        String nuevaContraseña = new String(jPasswordField3.getPassword());  // ← CAMBIADO
        
        // Actualizar la contraseña en la clase Login
        if (Login.USUARIOS_VALIDOS.containsKey(usuario)) {
            Login.USUARIOS_VALIDOS.put(usuario, nuevaContraseña);
            
            // También limpiar intentos fallidos si existían
            if (Login.INTENTOS_FALLIDOS.containsKey(usuario)) {
                Login.INTENTOS_FALLIDOS.remove(usuario);
            }
            
            // También limpiar bloqueo si existía
            if (Login.USUARIOS_BLOQUEADOS.containsKey(usuario)) {
                Login.USUARIOS_BLOQUEADOS.remove(usuario);
            }
            
            mostrarExito("✅ Contraseña actualizada exitosamente\n" +
                        "Usuario: " + usuario + "\n" +
                        "Ahora puede iniciar sesión con su nueva contraseña");
        } else {
            mostrarError("❌ Error: Usuario no encontrado en el sistema");
        }
    }
    
    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this,
            mensaje,
            "Error de validación",
            JOptionPane.ERROR_MESSAGE);
    }
    
    private void mostrarExito(String mensaje) {
        JOptionPane.showMessageDialog(this,
            mensaje,
            "Operación exitosa",
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        jPasswordField3 = new javax.swing.JPasswordField();
        btncancelar2 = new javax.swing.JToggleButton();
        btnconfirmar = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(224, 181, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));

        jLabel1.setBackground(new java.awt.Color(203, 130, 253));
        jLabel1.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nueva contraseña ___ BRAYMAR RESTAURANTE MARISQUERÍA");

        jLabel2.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 18)); // NOI18N
        jLabel2.setText("Nueva contraeña");

        jLabel3.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 18)); // NOI18N
        jLabel3.setText("Confirmar contraseña");

        jPasswordField3.addActionListener(this::jPasswordField3ActionPerformed);

        btncancelar2.setText("Cancelar");
        btncancelar2.addActionListener(this::btncancelar2ActionPerformed);

        btnconfirmar.setText("Confirmar");
        btnconfirmar.addActionListener(this::btnconfirmarActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(282, 282, 282)
                        .addComponent(btncancelar2)
                        .addGap(34, 34, 34)
                        .addComponent(btnconfirmar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 659, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 732, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 659, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPasswordField3, javax.swing.GroupLayout.PREFERRED_SIZE, 609, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 609, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(43, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(51, 51, 51)
                .addComponent(jLabel2)
                .addGap(35, 35, 35)
                .addComponent(jPasswordField3, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jLabel3)
                .addGap(35, 35, 35)
                .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 87, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btncancelar2)
                    .addComponent(btnconfirmar))
                .addGap(62, 62, 62))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 512, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btncancelar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncancelar2ActionPerformed
        // TODO add your handling code here:
            int confirm = JOptionPane.showConfirmDialog(this,
            "¿Cancelar cambio de contraseña?",
            "Confirmar cancelación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            Login ventanaLogin = new Login();
            ventanaLogin.setLocationRelativeTo(null);
            ventanaLogin.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_btncancelar2ActionPerformed

    private void jPasswordField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordField3ActionPerformed

    private void btnconfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnconfirmarActionPerformed
        if (validarContraseña()) {
            actualizarContraseñaEnLogin();
            
            // Redirigir al login
            Login ventanaLogin = new Login();
            ventanaLogin.setLocationRelativeTo(null);
            ventanaLogin.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_btnconfirmarActionPerformed


    private void jPasswordField3KeyPressed(java.awt.event.KeyEvent evt) {                                               
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            jPasswordField1.requestFocus();
        }
    }                                              

    private void jPasswordField1KeyPressed(java.awt.event.KeyEvent evt) {                                                  
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            btnconfirmarActionPerformed(null);
        }
    }                                                 

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new NuevaContraseña().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btncancelar2;
    private javax.swing.JToggleButton btnconfirmar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField3;
    // End of variables declaration//GEN-END:variables
}
