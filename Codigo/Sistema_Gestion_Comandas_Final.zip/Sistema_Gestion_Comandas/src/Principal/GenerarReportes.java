package Principal;

import javax.swing.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.awt.*;
import java.io.File;
import java.util.*;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;
import Modelo.ComandaData;
import java.util.Date;



public class GenerarReportes extends javax.swing.JFrame {
    private DecimalFormat df = new DecimalFormat("#,##0.00");
    private SimpleDateFormat sdfFecha = new SimpleDateFormat("dd/MM/yyyy");
    private SimpleDateFormat sdfHoraCompleta = new SimpleDateFormat("HH:mm:ss");
    private MenuPrincipal menuPrincipal;

    public GenerarReportes(MenuPrincipal menuPrincipal) {
        this.menuPrincipal = menuPrincipal;
        initComponents();
        inicializarComponentes();
        actualizarEstadisticas();
        setLocationRelativeTo(null);
    }
   
    
    public GenerarReportes() {
        this(null);
    }
    
    private void inicializarComponentes() {
        // Configurar título y textos
        lblMensajeEstado.setText("SISTEMA DE REPORTES DE VENTAS - RESTAURANTE BRAYMAR");
        lblMensajeEstado.setFont(new Font("Arial", Font.BOLD, 14));
        
        jLabel2.setText("TIPO DE REPORTE");
        
        // Configurar combo box
        cmbTipoReporte.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { 
            "📊 Reporte Diario", 
            "📈 Reporte Semanal", 
            "📅 Reporte Mensual", 
            "👤 Reporte por Cliente", 
            "🍽️ Productos Más Vendidos",
            "💰 Ventas Totales",
            "⏰ Hora Pico de Ventas"
        }));
        
        // Configurar botones
        btngenerar.setText("GENERAR REPORTE");
        btngenerar.setBackground(new Color(126, 0, 211));
        btngenerar.setForeground(Color.WHITE);
        btngenerar.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 12));
        
        btnexportar.setText("EXPORTAR PDF");
        btnexportar.setBackground(new Color(126, 0, 211));
        btnexportar.setForeground(Color.WHITE);
        btnexportar.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 12));
        
        btncerrar.setText("REGRESAR");
        btncerrar.setBackground(new Color(255,51,51));
        btncerrar.setForeground(Color.WHITE);
        btncerrar.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 12));
        
        // Configurar área de texto - CORRECCIÓN IMPORTANTE
        txtareareporte.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txtareareporte.setBackground(new Color(255, 255, 240));
       txtareareporte.setEditable(false);
        txtareareporte.setLineWrap(true);
        txtareareporte.setWrapStyleWord(true);
        
        // Configurar estadísticas
        lblventashoytitulo.setText("💰 VENTAS HOY:");
        lblcomandashoytitulo.setText("📦 COMANDA HOY:");
        lblclientefrecuentetitulo.setText("👤 CLIENTE FRECUENTE:");
        lblproductomasvendidotitulo.setText("🏆 PRODUCTO MÁS VENDIDO:");
        lblhorapicotitulo.setText("⏰ HORA PICO:");
        lblventasacumuladastitulo.setText("📈 VENTAS ACUMULADAS:");
        lblmenorventatitulo.setText("📉 MENOR VENTA:");
        lblmayorventatitulo.setText("📈 MAYOR VENTA:");
        
        // Configurar texto inicial en el área de reporte
        txtareareporte.setText("Seleccione un tipo de reporte y presione 'GENERAR REPORTE' para comenzar.");
    }
    
    private void actualizarEstadisticas() {
        if (GenerarComandas.todasLasComandas == null || GenerarComandas.todasLasComandas.isEmpty()) {
            resetearEstadisticas();
            txtareareporte.setText("⚠️ No hay datos de comandas disponibles.\n\n" +
                             "📌 Instrucciones:\n" +
                             "1. Ve al módulo 'Generar Comanda'\n" +
                             "2. Crea algunas comandas\n" +
                             "3. Regresa aquí para generar reportes\n\n" +
                             "Los reportes se basan en las comandas generadas.");
            return;
        }
        
        calcularEstadisticas();
    }
    
    private void resetearEstadisticas() {
        lblventashoy.setText("S/ 0.00");
        lblcomandashoy.setText("0");
        lblclientefrecuente.setText("-");
        jLabel11.setText("-");
        lblhorapico.setText("-");
        lblventasacumuladas.setText("S/ 0.00");
        lblmenorventa.setText("S/ 0.00");
        lblmayorventa.setText("S/ 0.00");
    }
    
    private void calcularEstadisticas() {
    if (GenerarComandas.todasLasComandas == null || GenerarComandas.todasLasComandas.isEmpty()) {
        resetearEstadisticas();
        txtareareporte.setText("⚠️ No hay datos de comandas disponibles.\n\n" +
                         "📌 Instrucciones:\n" +
                         "1. Ve al módulo 'Generar Comanda'\n" +
                         "2. Crea algunas comandas\n" +
                         "3. Regresa aquí para generar reportes\n\n" +
                         "Los reportes se basan en las comandas generadas.");
        return;
    }
    
    // Usar MongoDB si está disponible
    calcularEstadisticasConMongoDB();
}
    
    private String encontrarMayor(Map<String, Integer> mapa) {
        if (mapa.isEmpty()) return null;
        
        String maxKey = null;
        int maxValue = 0;
        
        for (Map.Entry<String, Integer> entry : mapa.entrySet()) {
            if (entry.getValue() > maxValue) {
                maxValue = entry.getValue();
                maxKey = entry.getKey();
            }
        }
        
        return maxKey;
    }
    
    private void generarReporte() {
    String tipoReporte = (String) cmbTipoReporte.getSelectedItem();
    
    if (GenerarComandas.todasLasComandas == null || GenerarComandas.todasLasComandas.isEmpty()) {
        JOptionPane.showMessageDialog(this,
            "❌ No hay datos disponibles para generar reportes.\n\n" +
            "Primero genera algunas comandas en el módulo 'Generar Comanda'.",
            "Sin Datos",
            JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    StringBuilder reporte = new StringBuilder();
    SimpleDateFormat sdfTitulo = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    
    // Encabezado limpio
    reporte.append("===============================================================\n");
    reporte.append("                  RESTAURANTE BRAYMAR - REPORTE                \n");
    reporte.append("===============================================================\n\n");
    
    reporte.append("Tipo de Reporte: ").append(tipoReporte.replace("📊", "").replace("📈", "").replace("📅", "").replace("👤", "").replace("🍽️", "").replace("💰", "").replace("⏰", "").trim()).append("\n");
    reporte.append("Fecha Generación: ").append(sdfFecha.format(new Date())).append("\n");
    reporte.append("Hora Generación: ").append(sdfHoraCompleta.format(new Date())).append("\n");
    reporte.append("----------------------------------------------------------------\n\n");
    
    if (tipoReporte.contains("Diario")) {
        generarReporteDiario(reporte);
    } else if (tipoReporte.contains("Semanal")) {
        generarReporteSemanal(reporte);
    } else if (tipoReporte.contains("Mensual")) {
        generarReporteMensual(reporte);
    } else if (tipoReporte.contains("Cliente")) {
        generarReporteCliente(reporte);
    } else if (tipoReporte.contains("Productos")) {
        generarReporteProductos(reporte);
    } else if (tipoReporte.contains("Ventas Totales")) {
        generarReporteVentasTotales(reporte);
    } else if (tipoReporte.contains("Hora Pico")) {
        generarReporteHoraPico(reporte);
    } else {
        reporte.append("Tipo de reporte no reconocido\n");
    }
    
    reporte.append("\n===============================================================\n");
    reporte.append("                      FIN DEL REPORTE                          \n");
    reporte.append("===============================================================\n");
    
    txtareareporte.setText(reporte.toString());
    
    // Actualizar estadísticas después de generar reporte
    calcularEstadisticas();
}

private void generarReporteDiario(StringBuilder reporte) {
    String hoy = sdfFecha.format(new Date());
    double totalHoy = 0;
    int comandasHoy = 0;
    int enProcesoHoy = 0;
    int listasHoy = 0;
    
    reporte.append("REPORTE DIARIO - ").append(hoy).append("\n");
    reporte.append("----------------------------------------------------------------\n\n");
    
    reporte.append("LISTA DE COMANDA DEL DÍA:\n\n");
    reporte.append("ID      CLIENTE               TOTAL      HORA    ESTADO\n");
    reporte.append("------  --------------------  ---------  ------  ----------\n");
    
    for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
        if (hoy.equals(comanda.fecha)) {
            reporte.append(String.format("#%04d   %-20s  S/ %7.2f  %6s  %-10s\n", 
                comanda.id, 
                comanda.cliente.length() > 20 ? comanda.cliente.substring(0, 17) + "..." : comanda.cliente,
                comanda.total,
                comanda.hora,
                comanda.estado));
            totalHoy += comanda.total;
            comandasHoy++;
            
            if ("EN_PROCESO".equals(comanda.estado)) enProcesoHoy++;
            else if ("LISTO".equals(comanda.estado)) listasHoy++;
        }
    }
    
    reporte.append("\n----------------------------------------------------------------\n");
    reporte.append("RESUMEN DEL DÍA:\n");
    reporte.append("----------------------------------------------------------------\n");
    reporte.append("• Total Comandas: ").append(comandasHoy).append("\n");
    reporte.append("• En Proceso: ").append(enProcesoHoy).append("\n");
    reporte.append("• Listas para Entregar: ").append(listasHoy).append("\n");
    reporte.append("• Total Ventas: S/ ").append(df.format(totalHoy)).append("\n");
    reporte.append("• Promedio por Comanda: S/ ").append(comandasHoy > 0 ? df.format(totalHoy / comandasHoy) : "0.00").append("\n");
}

private void generarReporteSemanal(StringBuilder reporte) {
    Calendar cal = Calendar.getInstance();
    String hoy = sdfFecha.format(cal.getTime());
    cal.add(Calendar.DAY_OF_YEAR, -7);
    String unaSemanaAtras = sdfFecha.format(cal.getTime());
    
    Map<String, Double> ventasPorDia = new LinkedHashMap<>();
    Map<String, Integer> comandasPorDia = new LinkedHashMap<>();
    double totalSemana = 0;
    int totalComandas = 0;
    
    // Inicializar días de la última semana
    String[] diasSemana = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
    for (int i = 6; i >= 0; i--) {
        Calendar diaCal = Calendar.getInstance();
        diaCal.add(Calendar.DAY_OF_YEAR, -i);
        String dia = diasSemana[diaCal.get(Calendar.DAY_OF_WEEK) - 2 < 0 ? 6 : diaCal.get(Calendar.DAY_OF_WEEK) - 2];
        ventasPorDia.put(dia, 0.0);
        comandasPorDia.put(dia, 0);
    }
    
    for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
        try {
            Date fechaComanda = sdfFecha.parse(comanda.fecha);
            if (!fechaComanda.before(cal.getTime())) {
                totalSemana += comanda.total;
                totalComandas++;
                
                Calendar fechaCal = Calendar.getInstance();
                fechaCal.setTime(fechaComanda);
                String dia = diasSemana[fechaCal.get(Calendar.DAY_OF_WEEK) - 2 < 0 ? 6 : fechaCal.get(Calendar.DAY_OF_WEEK) - 2];
                ventasPorDia.put(dia, ventasPorDia.get(dia) + comanda.total);
                comandasPorDia.put(dia, comandasPorDia.get(dia) + 1);
            }
        } catch (Exception e) {
            // Ignorar errores de parseo
        }
    }
    
    reporte.append("REPORTE SEMANAL (Últimos 7 días)\n");
    reporte.append("Desde: ").append(unaSemanaAtras).append(" - Hasta: ").append(hoy).append("\n");
    reporte.append("----------------------------------------------------------------\n\n");
    
    reporte.append("DÍA          COMANDA       VENTAS       PROMEDIO\n");
    reporte.append("----------  ----------  -----------  -----------\n");
    
    for (String dia : diasSemana) {
        double ventas = ventasPorDia.get(dia);
        int comandas = comandasPorDia.get(dia);
        double promedio = comandas > 0 ? ventas / comandas : 0;
        
        reporte.append(String.format("%-10s  %10d  S/ %8.2f  S/ %8.2f\n",
            dia, comandas, ventas, promedio));
    }
    
    reporte.append("\n----------------------------------------------------------------\n");
    reporte.append("RESUMEN SEMANAL:\n");
    reporte.append("----------------------------------------------------------------\n");
    reporte.append("• Total Comandas: ").append(totalComandas).append("\n");
    reporte.append("• Total Ventas: S/ ").append(df.format(totalSemana)).append("\n");
    reporte.append("• Promedio Diario: S/ ").append(df.format(totalSemana / 7)).append("\n");
    reporte.append("• Promedio por Comanda: S/ ").append(totalComandas > 0 ? df.format(totalSemana / totalComandas) : "0.00").append("\n");
}

private void generarReporteMensual(StringBuilder reporte) {
    Map<String, Double> ventasPorMes = new TreeMap<>();
    Map<String, Integer> comandasPorMes = new TreeMap<>();
    
    for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
        try {
            Date fecha = sdfFecha.parse(comanda.fecha);
            Calendar cal = Calendar.getInstance();
            cal.setTime(fecha);
            String mes = String.format("%02d/%d", cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR));
            
            ventasPorMes.put(mes, ventasPorMes.getOrDefault(mes, 0.0) + comanda.total);
            comandasPorMes.put(mes, comandasPorMes.getOrDefault(mes, 0) + 1);
        } catch (Exception e) {
            // Ignorar
        }
    }
    
    reporte.append("REPORTE MENSUAL\n");
    reporte.append("----------------------------------------------------------------\n\n");
    
    if (ventasPorMes.isEmpty()) {
        reporte.append("No hay datos mensuales disponibles.\n");
        return;
    }
    
    reporte.append("MES        COMANDA       VENTAS       PROMEDIO\n");
    reporte.append("--------  ----------  -----------  -----------\n");
    
    for (String mes : ventasPorMes.keySet()) {
        double ventas = ventasPorMes.get(mes);
        int comandas = comandasPorMes.get(mes);
        double promedio = comandas > 0 ? ventas / comandas : 0;
        
        reporte.append(String.format("%-8s  %10d  S/ %8.2f  S/ %8.2f\n",
            mes, comandas, ventas, promedio));
    }
}

private void generarReporteCliente(StringBuilder reporte) {
    Map<String, Double> ventasPorCliente = new HashMap<>();
    Map<String, Integer> comandasPorCliente = new HashMap<>();
    
    for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
        if (comanda.cliente != null && !comanda.cliente.trim().isEmpty()) {
            ventasPorCliente.put(comanda.cliente, ventasPorCliente.getOrDefault(comanda.cliente, 0.0) + comanda.total);
            comandasPorCliente.put(comanda.cliente, comandasPorCliente.getOrDefault(comanda.cliente, 0) + 1);
        }
    }
    
    reporte.append("REPORTE POR CLIENTE\n");
    reporte.append("----------------------------------------------------------------\n\n");
    
    if (ventasPorCliente.isEmpty()) {
        reporte.append("No hay datos de clientes disponibles.\n");
        return;
    }
    
    List<Map.Entry<String, Double>> listaTopClientes = new ArrayList<>(ventasPorCliente.entrySet());
    listaTopClientes.sort((a, b) -> b.getValue().compareTo(a.getValue()));
    
    reporte.append("Top 10 Clientes:\n\n");
    reporte.append("#   CLIENTE               COMANDA       VENTAS       PROMEDIO\n");
    reporte.append("--  --------------------  ----------  -----------  -----------\n");
    
    int i = 1;
    for (Map.Entry<String, Double> entry : listaTopClientes) {
        if (i > 10) break;
        
        String cliente = entry.getKey();
        double ventas = entry.getValue();
        int comandas = comandasPorCliente.get(cliente);
        double promedio = comandas > 0 ? ventas / comandas : 0;
        
        reporte.append(String.format("%2d  %-20s  %10d  S/ %8.2f  S/ %8.2f\n",
            i++,
            cliente.length() > 20 ? cliente.substring(0, 17) + "..." : cliente,
            comandas,
            ventas,
            promedio));
    }
}

private void generarReporteProductos(StringBuilder reporte) {
    Map<String, Integer> productosVendidos = new HashMap<>();
    Map<String, Double> ingresosPorProducto = new HashMap<>();
    
    for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
        if (comanda.productos != null) {
            for (String producto : comanda.productos) {
                String[] partes = producto.split("x ", 2);
                if (partes.length == 2) {
                    try {
                        int cantidad = Integer.parseInt(partes[0].trim());
                        String nombre = partes[1].trim();
                        productosVendidos.put(nombre, productosVendidos.getOrDefault(nombre, 0) + cantidad);
                        double precio = obtenerPrecioEstimado(nombre);
                        ingresosPorProducto.put(nombre, ingresosPorProducto.getOrDefault(nombre, 0.0) + (precio * cantidad));
                    } catch (NumberFormatException e) {
                        productosVendidos.put(producto, productosVendidos.getOrDefault(producto, 0) + 1);
                        double precio = obtenerPrecioEstimado(producto);
                        ingresosPorProducto.put(producto, ingresosPorProducto.getOrDefault(producto, 0.0) + precio);
                    }
                } else {
                    productosVendidos.put(producto, productosVendidos.getOrDefault(producto, 0) + 1);
                    double precio = obtenerPrecioEstimado(producto);
                    ingresosPorProducto.put(producto, ingresosPorProducto.getOrDefault(producto, 0.0) + precio);
                }
            }
        }
    }
    
    reporte.append("PRODUCTOS MÁS VENDIDOS\n");
    reporte.append("----------------------------------------------------------------\n\n");
    
    if (productosVendidos.isEmpty()) {
        reporte.append("No hay datos de productos vendidos.\n");
        return;
    }
    
    List<Map.Entry<String, Integer>> listaTopProductos = new ArrayList<>(productosVendidos.entrySet());
    listaTopProductos.sort((a, b) -> b.getValue().compareTo(a.getValue()));
    
    reporte.append("Top 10 Productos:\n\n");
    reporte.append("#   PRODUCTO                 CANTIDAD       INGRESOS\n");
    reporte.append("--  -----------------------  ----------  ------------\n");
    
    int i = 1;
    double totalIngresosProductos = 0;
    for (Map.Entry<String, Integer> entry : listaTopProductos) {
        if (i > 10) break;
        
        String producto = entry.getKey();
        int cantidad = entry.getValue();
        double ingresos = ingresosPorProducto.getOrDefault(producto, 0.0);
        totalIngresosProductos += ingresos;
        
        reporte.append(String.format("%2d  %-23s  %10d  S/ %9.2f\n",
            i++,
            producto.length() > 23 ? producto.substring(0, 20) + "..." : producto,
            cantidad,
            ingresos));
    }
    
    reporte.append("\n----------------------------------------------------------------\n");
    reporte.append("RESUMEN PRODUCTOS:\n");
    reporte.append("----------------------------------------------------------------\n");
    reporte.append("• Total Productos Diferentes: ").append(productosVendidos.size()).append("\n");
    reporte.append("• Total Unidades Vendidas: ").append(productosVendidos.values().stream().mapToInt(Integer::intValue).sum()).append("\n");
    reporte.append("• Total Ingresos por Productos: S/ ").append(df.format(totalIngresosProductos)).append("\n");
}

private void generarReporteHoraPico(StringBuilder reporte) {
    Map<String, Integer> ventasPorHora = new TreeMap<>();
    Map<String, Double> ingresosPorHora = new TreeMap<>();
    
    for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
        if (comanda.hora != null && !comanda.hora.isEmpty()) {
            try {
                String[] partes = comanda.hora.split(":");
                if (partes.length > 0) {
                    String hora = partes[0] + ":00";
                    ventasPorHora.put(hora, ventasPorHora.getOrDefault(hora, 0) + 1);
                    ingresosPorHora.put(hora, ingresosPorHora.getOrDefault(hora, 0.0) + comanda.total);
                }
            } catch (Exception e) {
                // Ignorar
            }
        }
    }
    
    reporte.append("HORA PICO DE VENTAS\n");
    reporte.append("----------------------------------------------------------------\n\n");
    
    if (ventasPorHora.isEmpty()) {
        reporte.append("No hay datos de horas disponibles.\n");
        return;
    }
    
    reporte.append("DISTRIBUCIÓN POR HORA:\n\n");
    reporte.append("HORA       COMANDA       VENTAS       PROMEDIO\n");
    reporte.append("--------  ----------  -----------  -----------\n");
    
    String horaPico = null;
    int maxComandas = 0;
    double maxVentas = 0;
    
    for (Map.Entry<String, Integer> entry : ventasPorHora.entrySet()) {
        String hora = entry.getKey();
        int comandas = entry.getValue();
        double ventas = ingresosPorHora.getOrDefault(hora, 0.0);
        double promedio = comandas > 0 ? ventas / comandas : 0;
        
        reporte.append(String.format("%-8s  %10d  S/ %8.2f  S/ %8.2f\n",
            hora, comandas, ventas, promedio));
        
        if (comandas > maxComandas) {
            maxComandas = comandas;
            horaPico = hora;
            maxVentas = ventas;
        }
    }
    
    if (horaPico != null) {
        reporte.append("\n----------------------------------------------------------------\n");
        reporte.append("ANÁLISIS HORA PICO:\n");
        reporte.append("----------------------------------------------------------------\n");
        reporte.append("• Hora Pico: ").append(horaPico).append("\n");
        reporte.append("• Comandas en Hora Pico: ").append(maxComandas).append("\n");
        reporte.append("• Ventas en Hora Pico: S/ ").append(df.format(maxVentas)).append("\n");
        reporte.append("• Promedio en Hora Pico: S/ ").append(maxComandas > 0 ? df.format(maxVentas / maxComandas) : "0.00").append("\n");
        
        reporte.append("\nRECOMENDACIONES:\n");
        reporte.append("----------------------------------------------------------------\n");
        reporte.append("• Aumentar personal en horario ").append(horaPico).append("\n");
        reporte.append("• Preparar inventario con anticipación\n");
        reporte.append("• Ofrecer promociones en horas de menor actividad\n");
    }
}

private void generarReporteVentasTotales(StringBuilder reporte) {
    double totalVentas = 0;
    int totalComandas = 0;
    int enProceso = 0;
    int listas = 0;
    String hoy = sdfFecha.format(new Date());
    double ventasHoy = 0;
    int comandasHoy = 0;
    
    for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
        totalVentas += comanda.total;
        totalComandas++;
        
        if (hoy.equals(comanda.fecha)) {
            ventasHoy += comanda.total;
            comandasHoy++;
        }
        
        if ("EN_PROCESO".equals(comanda.estado)) enProceso++;
        else if ("LISTO".equals(comanda.estado)) listas++;
    }
    
    reporte.append("REPORTE DE VENTAS TOTALES\n");
    reporte.append("----------------------------------------------------------------\n\n");
    
    reporte.append("ESTADÍSTICAS GENERALES:\n");
    reporte.append("----------------------------------------------------------------\n");
    reporte.append("• Total de Comandas Registradas: ").append(totalComandas).append("\n");
    reporte.append("• Total de Ventas Acumuladas: S/ ").append(df.format(totalVentas)).append("\n");
    reporte.append("• Promedio por Comanda: S/ ").append(totalComandas > 0 ? df.format(totalVentas / totalComandas) : "0.00").append("\n");
    reporte.append("• Ventas Hoy (").append(hoy).append("): S/ ").append(df.format(ventasHoy)).append("\n");
    reporte.append("• Comandas Hoy: ").append(comandasHoy).append("\n");
    
    reporte.append("\nESTADO DE COMANDA:\n");
    reporte.append("----------------------------------------------------------------\n");
    reporte.append("• En Proceso: ").append(enProceso).append("\n");
    reporte.append("• Listas para Entregar: ").append(listas).append("\n");
    reporte.append("• Total: ").append(enProceso + listas).append("\n");
    
    if (totalComandas > 0) {
        double porcentajeEnProceso = (enProceso * 100.0) / totalComandas;
        double porcentajeListas = (listas * 100.0) / totalComandas;
        
        reporte.append("\nPORCENTAJES:\n");
        reporte.append("----------------------------------------------------------------\n");
        reporte.append("• En Proceso: ").append(String.format("%.1f", porcentajeEnProceso)).append("%\n");
        reporte.append("• Listas: ").append(String.format("%.1f", porcentajeListas)).append("%\n");
    }
}
    
    private void exportarPDF() {
    if (txtareareporte.getText().trim().isEmpty() || 
        txtareareporte.getText().contains("No hay datos") ||
        txtareareporte.getText().contains("Seleccione un tipo de reporte")) {
        
        JOptionPane.showMessageDialog(this, 
            "⚠️ Primero debe generar un reporte válido\n" +
            "antes de poder exportarlo a PDF.",
            "No hay Reporte", 
            JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    try {
        // Usar el PrintDialog de Java y redirigir a PDF
        java.awt.print.PrinterJob job = java.awt.print.PrinterJob.getPrinterJob();
        
        // Crear documento imprimible
        job.setPrintable(new java.awt.print.Printable() {
            @Override
            public int print(java.awt.Graphics g, 
                           java.awt.print.PageFormat pf, 
                           int pageIndex) {
                if (pageIndex > 0) return java.awt.print.Printable.NO_SUCH_PAGE;
                
                java.awt.Graphics2D g2d = (java.awt.Graphics2D) g;
                g2d.translate(pf.getImageableX(), pf.getImageableY());
                
                // Configurar fuente
                g2d.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 10));
                
                // Dibujar contenido
                String[] lineas = txtareareporte.getText().split("\n");
                int y = 100;
                for (String linea : lineas) {
                    g2d.drawString(linea, 50, y);
                    y += 15;
                    if (y > 750) break; // No pasar del límite de página
                }
                
                return java.awt.print.Printable.PAGE_EXISTS;
            }
        });
        
        // Mostrar diálogo de impresión
        if (job.printDialog()) {
            // En Windows, si seleccionas "Microsoft Print to PDF" en el diálogo
            // y haces click en Imprimir, se crea el PDF directamente
            
            job.print();
            
            JOptionPane.showMessageDialog(this,
                "\n\n" +
                "✅PDF creado exitosamente",
                "Crear PDF",
                JOptionPane.INFORMATION_MESSAGE);
        }
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
            "❌ Error: " + e.getMessage() + "\n\n" +
            "Asegúrese de tener 'Microsoft Print to PDF'\n" +
            "en su impresora de Windows.",
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }
}

    private void regresarAlMenu() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "¿Regresar al menú principal?",
            "Confirmar Regreso",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            if (menuPrincipal != null) {
                menuPrincipal.setVisible(true);
                menuPrincipal.setLocationRelativeTo(null);
            }
        }
    }
    
    private void calcularEstadisticasConMongoDB() {
    // Primero intentar obtener estadísticas de MongoDB
    try {
        Map<String, Object> stats = ConexionMongoDB.obtenerEstadisticas();
        
        if (!stats.containsKey("error") || stats.get("error").equals(false)) {
            // Usar datos de MongoDB
            double ventasHoy = (double) stats.get("ventasHoy");
            double ventasAcumuladas = (double) stats.get("ventasTotales");
            long totalComandas = (long) stats.get("totalComandas");
            long comandasHoy = (long) stats.get("comandasHoy");
            
            lblventashoy.setText("S/ " + df.format(ventasHoy));
            lblventasacumuladas.setText("S/ " + df.format(ventasAcumuladas));
            lblcomandashoy.setText(String.valueOf(comandasHoy));
            
            // Para los otros datos, mantener cálculo local
            String clienteFrecuente = encontrarClienteFrecuente();
            String productoMasVendido = encontrarProductoMasVendido();
            String horaPico = encontrarHoraPico();
            
            lblclientefrecuente.setText(clienteFrecuente != null ? 
                (clienteFrecuente.length() > 10 ? clienteFrecuente.substring(0, 10) + "..." : clienteFrecuente) : "-");
            jLabel11.setText(productoMasVendido != null ? 
                (productoMasVendido.length() > 12 ? productoMasVendido.substring(0, 12) + "..." : productoMasVendido) : "-");
            lblhorapico.setText(horaPico != null ? horaPico : "-");
            
            // Calcular menor y mayor venta localmente
            double menorVenta = Double.MAX_VALUE;
            double mayorVenta = 0;
            
            for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
                if (comanda.total < menorVenta) menorVenta = comanda.total;
                if (comanda.total > mayorVenta) mayorVenta = comanda.total;
            }
            
            lblmenorventa.setText(menorVenta != Double.MAX_VALUE ? "S/ " + df.format(menorVenta) : "S/ 0.00");
            lblmayorventa.setText("S/ " + df.format(mayorVenta));
            
            System.out.println("✅ Estadísticas cargadas desde MongoDB");
        } else {
            // Si hay error, usar datos locales
            calcularEstadisticasLocales();
        }
    } catch (Exception e) {
        System.err.println("⚠️ Error con MongoDB, usando datos locales: " + e.getMessage());
        calcularEstadisticasLocales();
    }
}
@SuppressWarnings("unchecked")
public void calcularEstadisticasLocales() {
    if (GenerarComandas.todasLasComandas == null || GenerarComandas.todasLasComandas.isEmpty()) {
        resetearEstadisticas();
        return;
    }
    
    // Convertir lista a tipo correcto (ya es List<GenerarComandas.ComandaData>)
    List<GenerarComandas.ComandaData> comandas = GenerarComandas.todasLasComandas;
    
    // Calcular estadísticas
    double ventasTotales = 0;
    double ventasHoy = 0;
    int totalComandas = 0;
    int comandasHoy = 0;
    
    String hoy = sdfFecha.format(new Date());
    
    for (GenerarComandas.ComandaData comanda : comandas) {
        ventasTotales += comanda.total;
        totalComandas++;
        
        if (hoy.equals(comanda.fecha)) {
            ventasHoy += comanda.total;
            comandasHoy++;
        }
    }
    
    // Actualizar UI
    lblventashoy.setText("S/ " + df.format(ventasHoy));
    lblcomandashoy.setText(String.valueOf(comandasHoy));
    lblventasacumuladas.setText("S/ " + df.format(ventasTotales));
    
    // Otros cálculos
    String clienteFrecuente = encontrarClienteFrecuente();
    String productoMasVendido = encontrarProductoMasVendido();
    String horaPico = encontrarHoraPico();
    
    lblclientefrecuente.setText(clienteFrecuente != null ? 
        (clienteFrecuente.length() > 10 ? clienteFrecuente.substring(0, 10) + "..." : clienteFrecuente) : "-");
    jLabel11.setText(productoMasVendido != null ? 
        (productoMasVendido.length() > 12 ? productoMasVendido.substring(0, 12) + "..." : productoMasVendido) : "-");
    lblhorapico.setText(horaPico != null ? horaPico : "-");
    
    // Calcular menor y mayor venta
    double menorVenta = Double.MAX_VALUE;
    double mayorVenta = 0;
    
    for (GenerarComandas.ComandaData comanda : comandas) {
        if (comanda.total < menorVenta) menorVenta = comanda.total;
        if (comanda.total > mayorVenta) mayorVenta = comanda.total;
    }
    
    lblmenorventa.setText(menorVenta != Double.MAX_VALUE ? "S/ " + df.format(menorVenta) : "S/ 0.00");
    lblmayorventa.setText("S/ " + df.format(mayorVenta));
}
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblMensajeEstado = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cmbTipoReporte = new javax.swing.JComboBox<>();
        btngenerar = new javax.swing.JButton();
        btnexportar = new javax.swing.JButton();
        btncerrar = new javax.swing.JButton();
        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtareareporte = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        lblventashoytitulo = new javax.swing.JLabel();
        lblventashoy = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        lblcomandashoytitulo = new javax.swing.JLabel();
        lblcomandashoy = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        lblclientefrecuentetitulo = new javax.swing.JLabel();
        lblclientefrecuente = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        lblproductomasvendidotitulo = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        lblhorapicotitulo = new javax.swing.JLabel();
        lblhorapico = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        lblventasacumuladastitulo = new javax.swing.JLabel();
        lblventasacumuladas = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        lblmenorventatitulo = new javax.swing.JLabel();
        lblmenorventa = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        lblmayorventatitulo = new javax.swing.JLabel();
        lblmayorventa = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(126, 0, 211));

        lblMensajeEstado.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 18)); // NOI18N
        lblMensajeEstado.setForeground(new java.awt.Color(255, 255, 255));
        lblMensajeEstado.setText("Sistema de Reportes de Ventas - Restaurante Braymar");

        jPanel2.setBackground(new java.awt.Color(102, 255, 204));

        jLabel2.setBackground(new java.awt.Color(126, 0, 211));
        jLabel2.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(126, 0, 211));
        jLabel2.setText("Tipo De Reporte");

        cmbTipoReporte.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Reporte Diario", "Reporte Semanal", "Reporte Mensual", "Reporte por Cliente", "Productos Más Vendidos" }));
        cmbTipoReporte.addActionListener(this::cmbTipoReporteActionPerformed);

        btngenerar.setBackground(new java.awt.Color(126, 0, 211));
        btngenerar.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 24)); // NOI18N
        btngenerar.setForeground(new java.awt.Color(255, 255, 255));
        btngenerar.setText("Generar");
        btngenerar.addActionListener(this::btngenerarActionPerformed);

        btnexportar.setBackground(new java.awt.Color(126, 0, 211));
        btnexportar.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 24)); // NOI18N
        btnexportar.setForeground(new java.awt.Color(255, 255, 255));
        btnexportar.setText("Exportar PDF");
        btnexportar.addActionListener(this::btnexportarActionPerformed);

        btncerrar.setBackground(new java.awt.Color(255, 51, 51));
        btncerrar.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 24)); // NOI18N
        btncerrar.setForeground(new java.awt.Color(255, 255, 255));
        btncerrar.setText("Cerrar");
        btncerrar.addActionListener(this::btncerrarActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbTipoReporte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 270, Short.MAX_VALUE)
                .addComponent(btngenerar)
                .addGap(18, 18, 18)
                .addComponent(btnexportar)
                .addGap(18, 18, 18)
                .addComponent(btncerrar)
                .addGap(71, 71, 71))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cmbTipoReporte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btngenerar)
                    .addComponent(btncerrar)
                    .addComponent(btnexportar))
                .addGap(41, 41, 41))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblMensajeEstado))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblMensajeEstado)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jSplitPane1.setDividerLocation(550);

        jPanel3.setBackground(new java.awt.Color(126, 0, 211));
        jPanel3.setPreferredSize(new java.awt.Dimension(700, 471));

        txtareareporte.setColumns(20);
        txtareareporte.setRows(5);
        jScrollPane1.setViewportView(txtareareporte);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 517, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jSplitPane1.setLeftComponent(jPanel3);

        jPanel4.setBackground(new java.awt.Color(102, 255, 204));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        lblventashoytitulo.setText("Ventas Hoy:");

        lblventashoy.setText("S/ 0.00");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblventashoytitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblventashoy, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblventashoytitulo)
                    .addComponent(lblventashoy, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        lblcomandashoytitulo.setText("Comandas Hoy:");

        lblcomandashoy.setText("0");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblcomandashoytitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblcomandashoy, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblcomandashoytitulo)
                    .addComponent(lblcomandashoy))
                .addContainerGap())
        );

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        lblclientefrecuentetitulo.setText("Cliente Frecuente:");

        lblclientefrecuente.setText("-");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblclientefrecuentetitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblclientefrecuente, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblclientefrecuentetitulo)
                    .addComponent(lblclientefrecuente))
                .addContainerGap(8, Short.MAX_VALUE))
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        lblproductomasvendidotitulo.setText("Producto Más Vendido:");

        jLabel11.setText("-");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblproductomasvendidotitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 142, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblproductomasvendidotitulo)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        lblhorapicotitulo.setText("Hora Pico:");

        lblhorapico.setText("-");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblhorapicotitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblhorapico, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblhorapicotitulo)
                    .addComponent(lblhorapico))
                .addContainerGap())
        );

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));

        lblventasacumuladastitulo.setBackground(new java.awt.Color(255, 255, 255));
        lblventasacumuladastitulo.setText("Ventas Acumuladas:");

        lblventasacumuladas.setText("S/ 0.00  ");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblventasacumuladastitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblventasacumuladas, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblventasacumuladastitulo)
                    .addComponent(lblventasacumuladas))
                .addContainerGap())
        );

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));

        lblmenorventatitulo.setText("Menor Venta:");

        lblmenorventa.setText("S/ 0.00  ");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblmenorventatitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblmenorventa, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblmenorventatitulo)
                    .addComponent(lblmenorventa))
                .addContainerGap())
        );

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));

        lblmayorventatitulo.setText("Mayor Venta:");

        lblmayorventa.setText("S/ 0.00  ");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblmayorventatitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblmayorventa, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblmayorventatitulo)
                    .addComponent(lblmayorventa))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(97, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(53, Short.MAX_VALUE))
        );

        jSplitPane1.setRightComponent(jPanel4);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSplitPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 471, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btngenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngenerarActionPerformed
        // TODO add your handling code here:
        generarReporte();
    }//GEN-LAST:event_btngenerarActionPerformed

    private void btnexportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexportarActionPerformed
        // TODO add your handling code here:
        exportarPDF();
    }//GEN-LAST:event_btnexportarActionPerformed

    private void btncerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncerrarActionPerformed
        // TODO add your handling code here:
        regresarAlMenu();
    }//GEN-LAST:event_btncerrarActionPerformed

    private void cmbTipoReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTipoReporteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbTipoReporteActionPerformed
  
     public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        java.awt.EventQueue.invokeLater(() -> {
            new GenerarReportes().setVisible(true);
        });
    } 
    
       
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncerrar;
    private javax.swing.JButton btnexportar;
    private javax.swing.JButton btngenerar;
    private javax.swing.JComboBox<String> cmbTipoReporte;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JLabel lblMensajeEstado;
    private javax.swing.JLabel lblclientefrecuente;
    private javax.swing.JLabel lblclientefrecuentetitulo;
    private javax.swing.JLabel lblcomandashoy;
    private javax.swing.JLabel lblcomandashoytitulo;
    private javax.swing.JLabel lblhorapico;
    private javax.swing.JLabel lblhorapicotitulo;
    private javax.swing.JLabel lblmayorventa;
    private javax.swing.JLabel lblmayorventatitulo;
    private javax.swing.JLabel lblmenorventa;
    private javax.swing.JLabel lblmenorventatitulo;
    private javax.swing.JLabel lblproductomasvendidotitulo;
    private javax.swing.JLabel lblventasacumuladas;
    private javax.swing.JLabel lblventasacumuladastitulo;
    private javax.swing.JLabel lblventashoy;
    private javax.swing.JLabel lblventashoytitulo;
    private javax.swing.JTextArea txtareareporte;
    // End of variables declaration//GEN-END:variables

    private double obtenerPrecioEstimado(String producto) {
    // Mapa de precios de los productos
    Map<String, Double> preciosProductos = new HashMap<>();
    
    // Agregar precios de los productos del restaurante
    preciosProductos.put("Ceviche de Camarón", 7.50);
    preciosProductos.put("Ceviche de Pescado", 7.50);
    preciosProductos.put("Ceviche de Concha", 9.00);
    preciosProductos.put("Ceviche Mixto", 9.00);
    preciosProductos.put("Bambar", 12.00);
    preciosProductos.put("Cascada", 13.00);
    preciosProductos.put("Langostino a la plancha especial", 17.00);
    preciosProductos.put("Picada de Mixta", 11.00);
    preciosProductos.put("Jarra de limonada", 2.00);
    preciosProductos.put("Jarra de naranja", 2.50);
    preciosProductos.put("Agua", 0.75);
    preciosProductos.put("Cerveza", 3.50);
    preciosProductos.put("Arroz con Camarón", 8.00);
    preciosProductos.put("Arroz Mixto", 9.00);
    preciosProductos.put("Camarones Apanados", 8.00);
    preciosProductos.put("Camarones al Ajillo", 8.00);
    preciosProductos.put("Costillas BBQ", 5.50);
    preciosProductos.put("Alitas BBQ", 5.50);
    preciosProductos.put("Pechuga Mixta", 5.50);
    preciosProductos.put("Picada de carnes", 5.50);
    preciosProductos.put("Chicharrón de Pescado", 8.00);
    preciosProductos.put("Picudo a la Plancha", 8.00);
    preciosProductos.put("Encocado de Pescado", 8.00);
    preciosProductos.put("Filete Apanado", 8.00);
    preciosProductos.put("Camarón", 2.00);
    preciosProductos.put("Arroz", 1.50);
    preciosProductos.put("Papas", 1.50);
    preciosProductos.put("Patacones", 1.50);
    
    // Buscar por nombre exacto
    if (preciosProductos.containsKey(producto)) {
        return preciosProductos.get(producto);
    }
    
    // Buscar por palabra clave
    for (Map.Entry<String, Double> entry : preciosProductos.entrySet()) {
        if (producto.toLowerCase().contains(entry.getKey().toLowerCase()) || 
            entry.getKey().toLowerCase().contains(producto.toLowerCase())) {
            return entry.getValue();
        }
    }
    
    // Si contiene "Ceviche" pero no es específico
    if (producto.toLowerCase().contains("ceviche")) {
        return 30.00; // Precio promedio para ceviches
    }
    
    // Si contiene "bebida" o similar
    if (producto.toLowerCase().contains("bebida") || 
        producto.toLowerCase().contains("refresco") ||
        producto.toLowerCase().contains("jugo")) {
        return 8.00;
    }
    
    // Precio por defecto
    return 15.00;
}
    // MÉTODOS AÑADIR AL FINAL DE GenerarReportes.java

private String encontrarClienteFrecuente() {
    if (GenerarComandas.todasLasComandas == null || GenerarComandas.todasLasComandas.isEmpty()) {
        return null;
    }
    
    Map<String, Integer> frecuenciaClientes = new HashMap<>();
    
    for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
        if (comanda.cliente != null && !comanda.cliente.trim().isEmpty()) {
            frecuenciaClientes.put(comanda.cliente, 
                frecuenciaClientes.getOrDefault(comanda.cliente, 0) + 1);
        }
    }
    
    if (frecuenciaClientes.isEmpty()) {
        return null;
    }
    
    String clienteFrecuente = null;
    int maxFrecuencia = 0;
    
    for (Map.Entry<String, Integer> entry : frecuenciaClientes.entrySet()) {
        if (entry.getValue() > maxFrecuencia) {
            maxFrecuencia = entry.getValue();
            clienteFrecuente = entry.getKey();
        }
    }
    
    return clienteFrecuente;
}

private String encontrarProductoMasVendido() {
    if (GenerarComandas.todasLasComandas == null || GenerarComandas.todasLasComandas.isEmpty()) {
        return null;
    }
    
    Map<String, Integer> frecuenciaProductos = new HashMap<>();
    
    for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
        if (comanda.productos != null) {
            for (String producto : comanda.productos) {
                // Extraer solo el nombre del producto (sin cantidad)
                String nombreProducto = producto;
                if (producto.contains("x ")) {
                    nombreProducto = producto.substring(producto.indexOf("x ") + 2);
                }
                
                frecuenciaProductos.put(nombreProducto, 
                    frecuenciaProductos.getOrDefault(nombreProducto, 0) + 1);
            }
        }
    }
    
    if (frecuenciaProductos.isEmpty()) {
        return null;
    }
    
    String productoMasVendido = null;
    int maxFrecuencia = 0;
    
    for (Map.Entry<String, Integer> entry : frecuenciaProductos.entrySet()) {
        if (entry.getValue() > maxFrecuencia) {
            maxFrecuencia = entry.getValue();
            productoMasVendido = entry.getKey();
        }
    }
    
    return productoMasVendido;
}

private String encontrarHoraPico() {
    if (GenerarComandas.todasLasComandas == null || GenerarComandas.todasLasComandas.isEmpty()) {
        return null;
    }
    
    Map<String, Integer> frecuenciaHoras = new HashMap<>();
    
    for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
        if (comanda.hora != null && !comanda.hora.isEmpty()) {
            try {
                // Extraer solo la hora (ej: "14:30" -> "14")
                String[] partes = comanda.hora.split(":");
                if (partes.length > 0) {
                    String hora = partes[0] + ":00";
                    frecuenciaHoras.put(hora, 
                        frecuenciaHoras.getOrDefault(hora, 0) + 1);
                }
            } catch (Exception e) {
                // Ignorar errores de formato
            }
        }
    }
    
    if (frecuenciaHoras.isEmpty()) {
        return null;
    }
    
    String horaPico = null;
    int maxFrecuencia = 0;
    
    for (Map.Entry<String, Integer> entry : frecuenciaHoras.entrySet()) {
        if (entry.getValue() > maxFrecuencia) {
            maxFrecuencia = entry.getValue();
            horaPico = entry.getKey();
        }
    }
    
    return horaPico;
}
}