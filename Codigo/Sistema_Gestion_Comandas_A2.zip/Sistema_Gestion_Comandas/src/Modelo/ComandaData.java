package Modelo;

import java.util.Date;
import java.util.List;

public class ComandaData {
    private String id;
    private String nombreCliente;
    private String telefono;
    private String email;
    private String direccion;
    private Date fecha;
    private String estado; // "pendiente", "preparando", "entregada", "cancelada"
    private List<ItemComanda> items;
    private double total;
    private String metodoPago;
    private boolean esParaLlevar;
    
    // Constructor
    public ComandaData() {}
    
    // CORREGIDO: Getters y Setters correctos
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getNombreCliente() { return nombreCliente; }
    public void setNombreCliente(String nombreCliente) { this.nombreCliente = nombreCliente; }
    
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
    
    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }
    
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    
    public List<ItemComanda> getItems() { return items; }
    public void setItems(List<ItemComanda> items) { this.items = items; }
    
    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
    
    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }
    
    public boolean isEsParaLlevar() { return esParaLlevar; }
    public void setEsParaLlevar(boolean esParaLlevar) { this.esParaLlevar = esParaLlevar; }
}