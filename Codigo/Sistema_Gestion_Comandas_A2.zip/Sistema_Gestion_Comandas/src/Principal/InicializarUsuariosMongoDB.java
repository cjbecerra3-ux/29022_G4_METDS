package Principal;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import javax.swing.*;

public class InicializarUsuariosMongoDB {
    public static void main(String[] args) {
        String mensaje = "";
        
        try {
            System.out.println("🚀 INICIANDO INICIALIZACIÓN DE MONGODB");
            
            // 1. CONECTAR
            MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
            System.out.println("✅ Conectado a MongoDB");
            
            // 2. OBTENER/CREAR BASE DE DATOS
            MongoDatabase database = mongoClient.getDatabase("restaurante_braymar");
            System.out.println("✅ Base de datos: restaurante_braymar");
            
            // 3. CREAR COLECCIÓN SI NO EXISTE
            try {
                database.createCollection("usuarios");
                System.out.println("✅ Colección 'usuarios' creada");
            } catch (Exception e) {
                System.out.println("ℹ️ Colección 'usuarios' ya existe");
            }
            
            MongoCollection<Document> usuarios = database.getCollection("usuarios");
            
            // 4. ELIMINAR USUARIOS EXISTENTES
            usuarios.deleteMany(new Document());
            System.out.println("🗑️ Usuarios anteriores eliminados");
            
            // 5. INSERTAR NUEVOS USUARIOS
            Document admin = new Document("usuario", "admin")
                .append("contrasena", "admin123")
                .append("cedula", "0550655559")
                .append("fechaNacimiento", "30/11/2005")
                .append("colorFavorito", "negro")
                .append("nombre", "Administrador")
                .append("rol", "administrador")
                .append("activo", true)
                .append("intentosFallidos", 0)
                .append("bloqueado", false);
            
            Document gerente = new Document("usuario", "gerente")
                .append("contrasena", "gerente123")
                .append("cedula", "1234567890")
                .append("fechaNacimiento", "15/05/1990")
                .append("colorFavorito", "azul")
                .append("nombre", "Gerente del Restaurante")
                .append("rol", "gerente")
                .append("activo", true);
            
            Document cajero = new Document("usuario", "cajero")
                .append("contrasena", "cajero123")
                .append("cedula", "0987654321")
                .append("fechaNacimiento", "20/10/1995")
                .append("colorFavorito", "rojo")
                .append("nombre", "Cajero Principal")
                .append("rol", "cajero")
                .append("activo", true);
            
            Document mesero = new Document("usuario", "mesero")
                .append("contrasena", "mesero123")
                .append("cedula", "1112223334")
                .append("fechaNacimiento", "01/01/2000")
                .append("colorFavorito", "verde")
                .append("nombre", "Mesero Principal")
                .append("rol", "mesero")
                .append("activo", true);
            
            usuarios.insertMany(java.util.Arrays.asList(admin, gerente, cajero, mesero));
            
            long total = usuarios.countDocuments();
            
            mongoClient.close();
            
            mensaje = "✅ INICIALIZACIÓN EXITOSA!\n\n" +
                     "Usuarios creados: " + total + "\n\n" +
                     "🔐 CREDENCIALES:\n" +
                     "• admin / admin123\n" +
                     "• gerente / gerente123\n" +
                     "• cajero / cajero123\n" +
                     "• mesero / mesero123\n\n" +
                     "¡Ahora puedes usar el Login!";
            
            System.out.println(mensaje);
            
        } catch (Exception e) {
            mensaje = "❌ ERROR DE INICIALIZACIÓN:\n" + e.getMessage();
            System.err.println(mensaje);
        }
        
        JOptionPane.showMessageDialog(null, mensaje, 
            "Inicialización MongoDB", JOptionPane.INFORMATION_MESSAGE);
    }
}