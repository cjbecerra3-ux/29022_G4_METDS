package Principal;

import javax.swing.*;

public class VerConexion {
    public static void main(String[] args) {
        System.out.println("=== ¿ESTOY CONECTADO A MONGODB? ===");
        
        try {
            // Intento 1: Probar si las clases de MongoDB existen
            System.out.println("1️⃣  Probando si tengo las librerías...");
            Class.forName("com.mongodb.client.MongoClient");
            System.out.println("   ✅ Librerías MongoDB: SÍ tengo");
            
            // Intento 2: Probar conexión real
            System.out.println("2️⃣  Intentando conectar...");
            com.mongodb.client.MongoClient cliente = 
                com.mongodb.client.MongoClients.create("mongodb://127.0.0.1:27017");
            
            System.out.println("   ✅ Conexión establecida");
            
            // Intento 3: Ver qué hay en la base de datos
            System.out.println("3️⃣  Mirando dentro de la base de datos...");
            var baseDatos = cliente.getDatabase("restaurante_braymar");
            
            System.out.println("   📂 Base de datos: " + baseDatos.getName());
            
            // Contar colecciones
            int contador = 0;
            System.out.println("   📁 Colecciones encontradas:");
            for (String nombre : baseDatos.listCollectionNames()) {
                System.out.println("      • " + nombre);
                contador++;
            }
            
            if (contador == 0) {
                System.out.println("      ℹ️  No hay colecciones (todavía)");
            }
            
            // RESULTADO FINAL
            System.out.println("\n🎉🎉🎉 ¡RESULTADO FINAL! 🎉🎉🎉");
            System.out.println("=================================");
            System.out.println("¿Estoy conectado a MongoDB?");
            System.out.println("✅✅✅ ¡SÍ, ESTÁS CONECTADO! ✅✅✅");
            System.out.println("=================================");
            
            // Mostrar ventana de éxito
            JOptionPane.showMessageDialog(null,
                "🎉 ¡SÍ ESTÁS CONECTADO A MONGODB! 🎉\n\n" +
                "📡 Servidor: 127.0.0.1:27017\n" +
                "💾 Base de datos: restaurante_braymar\n" +
                "📁 Colecciones: " + contador + "\n\n" +
                "✅ Tu aplicación puede guardar datos\n" +
                "✅ Tu aplicación puede leer datos\n" +
                "✅ MongoDB está funcionando perfectamente",
                "¡CONEXIÓN EXITOSA!",
                JOptionPane.INFORMATION_MESSAGE);
            
            cliente.close();
            
        } catch (ClassNotFoundException e) {
            System.out.println("❌❌❌ NO tienes las librerías de MongoDB");
            JOptionPane.showMessageDialog(null,
                "❌ FALTAN LIBRERÍAS\n\n" +
                "No tienes los archivos .jar de MongoDB.\n\n" +
                "Solucion:\n" +
                "1. Ve a Project Properties → Libraries\n" +
                "2. Agrega:\n" +
                "   • mongodb-driver-sync-4.10.2.jar\n" +
                "   • bson-4.10.2.jar\n" +
                "   • mongodb-driver-core-4.10.2.jar",
                "Error Grave",
                JOptionPane.ERROR_MESSAGE);
            
        } catch (Exception e) {
            System.out.println("❌❌❌ NO estás conectado");
            System.out.println("   Razón: " + e.getMessage());
            
            JOptionPane.showMessageDialog(null,
                "❌ NO HAY CONEXIÓN A MONGODB\n\n" +
                "Error: " + e.getMessage() + "\n\n" +
                "¿MongoDB está instalado y corriendo?\n\n" +
                "Para verificar, abre CMD y escribe:\n" +
                "net start MongoDB",
                "Sin Conexión",
                JOptionPane.WARNING_MESSAGE);
        }
    }
}