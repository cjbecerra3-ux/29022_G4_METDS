package Principal;

import javax.swing.JOptionPane;

public class TestLibrerias {
    public static void main(String[] args) {
        System.out.println("=== PRUEBA DE LIBRERÍAS MONGODB ===");
        
        boolean todoBien = true;
        StringBuilder mensaje = new StringBuilder();
        
        try {
            Class.forName("org.bson.Document");
            System.out.println("✅ bson-4.10.2.jar - OK");
            mensaje.append("• bson-4.10.2.jar ✓\n");
        } catch (ClassNotFoundException e) {
            System.err.println("❌ ERROR: bson-4.10.2.jar NO encontrado");
            mensaje.append("• bson-4.10.2.jar ✗ (FALTA)\n");
            todoBien = false;
        }
        
        try {
            Class.forName("com.mongodb.client.MongoClient");
            System.out.println("✅ mongodb-driver-sync-4.10.2.jar - OK");
            mensaje.append("• mongodb-driver-sync-4.10.2.jar ✓\n");
        } catch (ClassNotFoundException e) {
            System.err.println("❌ ERROR: mongodb-driver-sync-4.10.2.jar NO encontrado");
            mensaje.append("• mongodb-driver-sync-4.10.2.jar ✗ (FALTA)\n");
            todoBien = false;
        }
        
        try {
            Class.forName("com.mongodb.internal.connection.DefaultClusterFactory");
            System.out.println("✅ mongodb-driver-core-4.10.2.jar - OK");
            mensaje.append("• mongodb-driver-core-4.10.2.jar ✓\n");
        } catch (ClassNotFoundException e) {
            System.err.println("❌ ERROR: mongodb-driver-core-4.10.2.jar NO encontrado");
            mensaje.append("• mongodb-driver-core-4.10.2.jar ✗ (FALTA)\n");
            todoBien = false;
        }
        
        // Mostrar resultado
        if (todoBien) {
            JOptionPane.showMessageDialog(null,
                "✅ TODAS las librerías MongoDB están cargadas\n\n" +
                mensaje.toString() + "\n" +
                "¡Listo para usar!",
                "Prueba Exitosa",
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null,
                "❌ FALTAN librerías MongoDB\n\n" +
                mensaje.toString() + "\n\n" +
                "Acciones necesarias:\n" +
                "1. Descarga los JARs faltantes\n" +
                "2. Agrégalos en Project Properties → Libraries\n" +
                "3. Haz Clean and Build",
                "Error de Configuración",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}