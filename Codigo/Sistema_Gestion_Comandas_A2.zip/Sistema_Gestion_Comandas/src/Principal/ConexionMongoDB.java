package Principal;

import com.mongodb.client.*;
import com.mongodb.MongoException;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import org.bson.conversions.Bson;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class ConexionMongoDB {
    private static MongoClient mongoClient;
    private static MongoDatabase database;
    private static final String CONNECTION_STRING = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "restaurante_braymar";
    
    // Método para conectar
    public static boolean conectar() {
        try {
            if (mongoClient == null) {
                mongoClient = MongoClients.create(CONNECTION_STRING);
                database = mongoClient.getDatabase(DATABASE_NAME);
                System.out.println("✅ Conexión establecida con MongoDB");
            }
            return true;
        } catch (MongoException e) {
            System.err.println("❌ Error conectando a MongoDB: " + e.getMessage());
            return false;
        }
    }
    
    // Método para desconectar
    public static void desconectar() {
        try {
            if (mongoClient != null) {
                mongoClient.close();
                mongoClient = null;
                database = null;
                System.out.println("🔌 Desconectado de MongoDB");
            }
        } catch (Exception e) {
            System.err.println("❌ Error al desconectar: " + e.getMessage());
        }
    }
    
    // GUARDAR UNA COMANDA
    public static void guardarComanda(GenerarComandas.ComandaData comanda) {
        try {
            if (!conectar()) {
                System.err.println("⚠️ No se pudo conectar a MongoDB");
                return;
            }
            
            MongoCollection<Document> coleccion = database.getCollection("comandas");
            
            Document doc = new Document();
            doc.append("id", comanda.id);
            doc.append("cliente", comanda.cliente);
            doc.append("mesero", comanda.mesero != null ? comanda.mesero : "MESERO-01");
            doc.append("estado", comanda.estado != null ? comanda.estado : "EN_PROCESO");
            doc.append("fecha", comanda.fecha != null ? comanda.fecha : new Date().toString());
            doc.append("hora", comanda.hora != null ? comanda.hora : new Date().toString());
            doc.append("horaCreacion", comanda.horaCreacion != null ? comanda.horaCreacion : new Date());
            doc.append("horaListo", comanda.horaListo != null ? comanda.horaListo : null);
            doc.append("comentarios", comanda.comentarios != null ? comanda.comentarios : "");
            doc.append("total", comanda.total);
            doc.append("productos", comanda.productos != null ? comanda.productos : new ArrayList<String>());
            
            Document existe = coleccion.find(Filters.eq("id", comanda.id)).first();
            if (existe != null) {
                coleccion.replaceOne(Filters.eq("id", comanda.id), doc);
                System.out.println("✅ Comanda #" + comanda.id + " actualizada en MongoDB");
            } else {
                coleccion.insertOne(doc);
                System.out.println("✅ Comanda #" + comanda.id + " guardada en MongoDB");
            }
            
        } catch (Exception e) {
            System.err.println("❌ Error al guardar comanda en MongoDB: " + e.getMessage());
            e.printStackTrace();
        } finally {
            desconectar();
        }
    }
    
    // OBTENER TODAS LAS COMANDAS
    public static List<GenerarComandas.ComandaData> obtenerTodasComandas() {
        List<GenerarComandas.ComandaData> comandas = new ArrayList<>();
        try {
            if (!conectar()) {
                System.err.println("⚠️ No se pudo conectar a MongoDB");
                return comandas;
            }
            
            MongoCollection<Document> coleccion = database.getCollection("comandas");
            
            for (Document doc : coleccion.find()) {
                GenerarComandas.ComandaData comanda = convertirDocumentAComanda(doc);
                if (comanda != null) {
                    comandas.add(comanda);
                }
            }
            
            System.out.println("📊 " + comandas.size() + " comandas obtenidas de MongoDB");
            
        } catch (Exception e) {
            System.err.println("❌ Error al obtener comandas: " + e.getMessage());
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return comandas;
    }
    
    // ACTUALIZAR ESTADO DE UNA COMANDA
    public static void actualizarEstadoComanda(int id, String nuevoEstado) {
        try {
            if (!conectar()) {
                System.err.println("⚠️ No se pudo conectar a MongoDB");
                return;
            }
            
            MongoCollection<Document> coleccion = database.getCollection("comandas");
            
            Bson filtro = Filters.eq("id", id);
            Bson actualizacion;
            
            if (nuevoEstado.equals("LISTO")) {
                actualizacion = Updates.combine(
                    Updates.set("estado", nuevoEstado),
                    Updates.set("horaListo", new Date())
                );
            } else {
                actualizacion = Updates.set("estado", nuevoEstado);
            }
            
            coleccion.updateOne(filtro, actualizacion);
            System.out.println("✅ Estado de comanda #" + id + " actualizado a: " + nuevoEstado);
            
        } catch (Exception e) {
            System.err.println("❌ Error al actualizar estado: " + e.getMessage());
            e.printStackTrace();
        } finally {
            desconectar();
        }
    }
    
    // CONVERTIR DOCUMENT A COMANDA
    private static GenerarComandas.ComandaData convertirDocumentAComanda(Document doc) {
        try {
            if (doc == null) {
                return null;
            }
            
            Integer id = doc.getInteger("id");
            String cliente = doc.getString("cliente");
            String mesero = doc.getString("mesero");
            List<String> productos = doc.getList("productos", String.class);
            String comentarios = doc.getString("comentarios");
            Double total = doc.getDouble("total");
            
            if (id == null || cliente == null || total == null) {
                System.err.println("⚠️ Documento incompleto, faltan campos esenciales");
                return null;
            }
            
            if (productos == null) {
                productos = new ArrayList<>();
            }
            
            GenerarComandas.ComandaData comanda = new GenerarComandas.ComandaData(
                id,
                cliente,
                mesero != null ? mesero : "MESERO-01",
                productos,
                comentarios != null ? comentarios : "",
                total
            );
            
            comanda.estado = doc.getString("estado");
            comanda.fecha = doc.getString("fecha");
            comanda.hora = doc.getString("hora");
            
            if (doc.containsKey("horaCreacion")) {
                comanda.horaCreacion = doc.getDate("horaCreacion");
            }
            
            if (doc.containsKey("horaListo")) {
                comanda.horaListo = doc.getDate("horaListo");
            }
            
            return comanda;
            
        } catch (Exception e) {
            System.err.println("❌ Error convirtiendo documento a comanda: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    // OBTENER ESTADÍSTICAS
    public static Map<String, Object> obtenerEstadisticas() {
        Map<String, Object> stats = new HashMap<>();
        try {
            if (!conectar()) {
                stats.put("error", "No se pudo conectar a MongoDB");
                return stats;
            }
            
            MongoCollection<Document> coleccion = database.getCollection("comandas");
            
            double ventasTotales = 0;
            double ventasHoy = 0;
            long totalComandas = 0;
            long comandasHoy = 0;
            
            String hoy = new java.text.SimpleDateFormat("dd/MM/yyyy").format(new Date());
            
            List<GenerarComandas.ComandaData> comandas = obtenerTodasComandas();
            for (GenerarComandas.ComandaData comanda : comandas) {
                ventasTotales += comanda.total;
                totalComandas++;
                
                if (comanda.fecha != null && comanda.fecha.equals(hoy)) {
                    ventasHoy += comanda.total;
                    comandasHoy++;
                }
            }
            
            stats.put("ventasTotales", ventasTotales);
            stats.put("ventasHoy", ventasHoy);
            stats.put("totalComandas", totalComandas);
            stats.put("comandasHoy", comandasHoy);
            stats.put("error", false);
            
            System.out.println("📈 Estadísticas obtenidas: Ventas Hoy S/" + ventasHoy);
            
        } catch (Exception e) {
            System.err.println("❌ Error obteniendo estadísticas: " + e.getMessage());
            e.printStackTrace();
            stats.put("error", e.getMessage());
        } finally {
            desconectar();
        }
        return stats;
    }
    
    // MÉTODO PARA PROBAR CONEXIÓN
    public static boolean probarConexion() {
        try {
            System.out.println("🧪 Probando conexión a MongoDB...");
            
            if (!conectar()) {
                System.err.println("❌ No se pudo conectar a MongoDB");
                return false;
            }
            
            for (String nombre : database.listCollectionNames()) {
                System.out.println("📁 Colección encontrada: " + nombre);
            }
            
            System.out.println("✅ Conexión a MongoDB exitosa");
            return true;
            
        } catch (Exception e) {
            System.err.println("❌ Error probando conexión: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }
    
    // MÉTODO PARA LIMPIAR LA BASE DE DATOS
    public static void limpiarBaseDatos() {
        try {
            if (!conectar()) {
                System.err.println("⚠️ No se pudo conectar para limpiar");
                return;
            }
            
            MongoCollection<Document> coleccion = database.getCollection("comandas");
            coleccion.deleteMany(new Document());
            System.out.println("🧹 Base de datos limpiada");
            
        } catch (Exception e) {
            System.err.println("❌ Error limpiando base de datos: " + e.getMessage());
        } finally {
            desconectar();
        }
    }
    
    // MÉTODO PARA OBTENER COMANDA POR ID
    public static GenerarComandas.ComandaData obtenerComandaPorId(int id) {
        try {
            if (!conectar()) {
                System.err.println("⚠️ No se pudo conectar a MongoDB");
                return null;
            }
            
            MongoCollection<Document> coleccion = database.getCollection("comandas");
            Document doc = coleccion.find(Filters.eq("id", id)).first();
            
            if (doc != null) {
                return convertirDocumentAComanda(doc);
            }
            
            System.out.println("ℹ️ Comanda #" + id + " no encontrada en MongoDB");
            return null;
            
        } catch (Exception e) {
            System.err.println("❌ Error obteniendo comanda por ID: " + e.getMessage());
            return null;
        } finally {
            desconectar();
        }
    }
    
    // MÉTODO PARA CONTAR COMANDAS
    public static long contarComandas() {
        try {
            if (!conectar()) {
                System.err.println("⚠️ No se pudo conectar a MongoDB");
                return 0;
            }
            
            MongoCollection<Document> coleccion = database.getCollection("comandas");
            long count = coleccion.countDocuments();
            
            System.out.println("📊 Total comandas en MongoDB: " + count);
            return count;
            
        } catch (Exception e) {
            System.err.println("❌ Error contando comandas: " + e.getMessage());
            return 0;
        } finally {
            desconectar();
        }
    }
    
    public static int obtenerSiguienteId() {
        try {
            MongoClient mongoClient = MongoClients.create("mongodb://127.0.0.1:27017");
            MongoDatabase database = mongoClient.getDatabase("restaurante_braymar");
            MongoCollection<Document> comandas = database.getCollection("comandas");
            
            Document maxDoc = comandas.find().sort(new Document("id", -1)).first();
            
            if (maxDoc != null && maxDoc.containsKey("id")) {
                int maxId = maxDoc.getInteger("id");
                System.out.println("📊 ID máximo encontrado: " + maxId);
                mongoClient.close();
                return maxId + 1;
            }
            mongoClient.close();
            return 1;
            
        } catch (Exception e) {
            System.err.println("❌ Error obteniendo siguiente ID: " + e.getMessage());
            return (int) (System.currentTimeMillis() % 10000) + 1000;
        }
    }
    
    public static boolean borrarTodasLasComandas() {
        MongoClient mongoClient = null;
        try {
            mongoClient = MongoClients.create("mongodb://localhost:27017");
            MongoDatabase database = mongoClient.getDatabase("restaurante_braymar");
            MongoCollection<Document> comandas = database.getCollection("comandas");
            
            long countBefore = comandas.countDocuments();
            comandas.deleteMany(new Document());
            long countAfter = comandas.countDocuments();
            
            System.out.println("🗑️ Borradas " + (countBefore - countAfter) + " comandas de MongoDB");
            return true;
            
        } catch (Exception e) {
            System.err.println("❌ Error borrando comandas: " + e.getMessage());
            return false;
        } finally {
            if (mongoClient != null) {
                mongoClient.close();
            }
        }
    }
    
    // MÉTODO ÚNICO PARA VERIFICAR CONTRASEÑA
    public static boolean verificarContraseñaAdmin(String contraseñaIngresada) {
        try {
            // Intenta verificar desde MongoDB
            MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
            MongoDatabase database = mongoClient.getDatabase("restaurante_braymar");
            MongoCollection<Document> usuarios = database.getCollection("usuarios");
            
            Document query = new Document("usuario", "admin")
                                .append("rol", "administrador");
            
            Document adminDoc = usuarios.find(query).first();
            mongoClient.close();
            
            if (adminDoc != null) {
                String contrasenaGuardada = adminDoc.getString("contrasena");
                if (contrasenaGuardada != null) {
                    boolean esCorrecta = contrasenaGuardada.equals(contraseñaIngresada);
                    System.out.println("🔐 Verificación MongoDB: " + (esCorrecta ? "✅ CORRECTA" : "❌ INCORRECTA"));
                    return esCorrecta;
                }
            }
            
            // Si no hay admin en MongoDB, usa contraseña por defecto
            System.out.println("⚠️ Usando contraseña por defecto");
            String contraseñaMaestra = "admin123";
            return contraseñaMaestra.equals(contraseñaIngresada);
            
        } catch (Exception e) {
            System.err.println("⚠️ Error conectando a MongoDB, usando contraseña local: " + e.getMessage());
            
            // Fallback a contraseña local
            String contraseñaMaestra = "admin123";
            boolean esCorrecta = contraseñaMaestra.equals(contraseñaIngresada);
            System.out.println("🔐 Verificación local: " + (esCorrecta ? "✅ CORRECTA" : "❌ INCORRECTA"));
            return esCorrecta;
        }
    }
}
// FIN DE LA CLASE ConexionMongoDB - NO AGREGAR NADA MÁS DESPUÉS DE ESTA LÍNEA