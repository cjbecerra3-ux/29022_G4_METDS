package Principal;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import javax.swing.JOptionPane;

public class TestConexionMongoDB {
    public static void main(String[] args) {
        System.out.println("🧪 INICIANDO PRUEBA DE CONEXIÓN MONGODB");
        
        // Configuración - AJUSTA ESTO SEGÚN TU INSTALACIÓN
        String connectionString;
        
        // OPCIÓN 1: MongoDB LOCAL (instalado en tu PC)
        connectionString = "mongodb://localhost:27017";
        // OPCIÓN 2: MongoDB Atlas (en la nube)
        // connectionString = "mongodb+srv://usuario:password@cluster.mongodb.net/";
        
        String databaseName = "restaurante_braymar"; // Nombre de tu BD
        
        try {
            // 1. CONEXIÓN
            System.out.println("🔌 Conectando a: " + connectionString);
            MongoClient mongoClient = MongoClients.create(connectionString);
            
            // 2. OBTENER BASE DE DATOS
            System.out.println("📂 Accediendo a base de datos: " + databaseName);
            MongoDatabase database = mongoClient.getDatabase(databaseName);
            
            // 3. LISTAR COLECCIONES (para verificar)
            System.out.println("📊 Colecciones disponibles:");
            MongoIterable<String> collectionNames = database.listCollectionNames();
            int count = 0;
            for (String name : collectionNames) {
                System.out.println("   • " + name);
                count++;
            }
            
            // 4. CREAR COLECCIÓN DE PRUEBA (si no hay)
            if (count == 0) {
                System.out.println("ℹ️ No hay colecciones. Creando 'prueba_conexion'...");
                database.createCollection("prueba_conexion");
                System.out.println("✅ Colección 'prueba_conexion' creada");
            }
            
            // 5. MENSAJE DE ÉXITO
            String mensaje = "✅ ¡CONEXIÓN EXITOSA A MONGODB!\n\n" +
                           "📡 Servidor: " + connectionString + "\n" +
                           "💾 Base de datos: " + databaseName + "\n" +
                           "📁 Colecciones: " + count + "\n" +
                           "🟢 Estado: CONECTADO";
            
            System.out.println("\n" + mensaje);
            
            JOptionPane.showMessageDialog(null, mensaje, 
                "Conexión Exitosa", JOptionPane.INFORMATION_MESSAGE);
            
            // 6. CERRAR CONEXIÓN
            mongoClient.close();
            
        } catch (Exception e) {
            String errorMsg = "❌ ERROR DE CONEXIÓN\n\n" +
                            "Mensaje: " + e.getMessage() + "\n\n" +
                            "📋 VERIFICA:\n" +
                            "1. MongoDB instalado y corriendo\n" +
                            "2. Puerto 27017 abierto\n" +
                            "3. Firewall desactivado\n" +
                            "4. Servicio MongoDB iniciado\n\n" +
                            "💡 SOLUCIÓN: Abre CMD como administrador y ejecuta:\n" +
                            "   net start MongoDB";
            
            System.err.println(errorMsg);
            e.printStackTrace();
            
            JOptionPane.showMessageDialog(null, errorMsg, 
                "Error de Conexión", JOptionPane.ERROR_MESSAGE);
        }
    }
}