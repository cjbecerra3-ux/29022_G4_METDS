package Principal;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import javax.swing.JOptionPane;

public class CrearSoloAdmin {
    
    static {
        // Silenciar logs de MongoDB
        System.setProperty("DEBUG.MONGO", "false");
        System.setProperty("DB.TRACE", "false");
        java.util.logging.Logger.getLogger("org.mongodb.driver").setLevel(java.util.logging.Level.SEVERE);
    }
    
    public static void main(String[] args) {
        try {
            System.out.println("👤 CREANDO SOLO USUARIO ADMIN");
            
            // 1. Conectar
            MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
            MongoDatabase database = mongoClient.getDatabase("restaurante_braymar");
            
            // 2. Crear colección si no existe
            try {
                database.createCollection("usuarios");
                System.out.println("✅ Colección 'usuarios' creada");
            } catch (Exception e) {
                System.out.println("ℹ️ Colección 'usuarios' ya existe");
            }
            
            MongoCollection<Document> usuarios = database.getCollection("usuarios");
            
            // 3. Crear SOLO el usuario admin
            Document admin = new Document("usuario", "admin")
                .append("contrasena", "admin123")
                .append("cedula", "0550655559")
                .append("fechaNacimiento", "30/11/2005")
                .append("colorFavorito", "negro")
                .append("nombre", "Administrador")
                .append("rol", "administrador")
                .append("activo", true)
                .append("intentosFallidos", 0)
                .append("bloqueado", false);
            
            // 4. Verificar si ya existe
            Document query = new Document("usuario", "admin");
            Document existe = usuarios.find(query).first();
            
            if (existe != null) {
                System.out.println("ℹ️ El usuario 'admin' ya existe, actualizando...");
                usuarios.replaceOne(query, admin);
            } else {
                System.out.println("➕ Insertando nuevo usuario 'admin'...");
                usuarios.insertOne(admin);
            }
            
            // 5. Verificar
            long total = usuarios.countDocuments();
            System.out.println("✅ Total usuarios: " + total);
            
            mongoClient.close();
            
            JOptionPane.showMessageDialog(null,
                "✅ USUARIO ADMIN CREADO\n\n" +
                "Usuario: admin\n" +
                "Contraseña: admin123\n" +
                "Cédula: 0550655559\n\n" +
                "¡Ahora puedes iniciar sesión!",
                "Usuario Creado",
                JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            JOptionPane.showMessageDialog(null,
                "❌ Error creando usuario:\n" + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}