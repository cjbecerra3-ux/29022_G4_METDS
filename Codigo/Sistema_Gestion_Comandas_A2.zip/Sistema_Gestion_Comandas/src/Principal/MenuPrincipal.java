package Principal;

import javax.swing.*;
import java.util.logging.Logger;

public class MenuPrincipal extends javax.swing.JFrame {
    
    private static final Logger logger = Logger.getLogger(MenuPrincipal.class.getName());

    public MenuPrincipal() {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Sistema de Gestión - Restaurante Braymar");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btngenerarcomanda = new javax.swing.JToggleButton();
        btnvisualizarcomanda = new javax.swing.JToggleButton();
        btngenerarreporte = new javax.swing.JToggleButton();
        btncerrarsesion = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(230, 196, 255));

        jLabel1.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 61)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("BRAYMAR");

        btngenerarcomanda.setBackground(new java.awt.Color(204, 204, 204));
        btngenerarcomanda.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 24)); // NOI18N
        btngenerarcomanda.setForeground(new java.awt.Color(255, 255, 255));
        btngenerarcomanda.setText("Generar Comanda");
        btngenerarcomanda.addActionListener(this::btngenerarcomandaActionPerformed);

        btnvisualizarcomanda.setBackground(new java.awt.Color(204, 204, 204));
        btnvisualizarcomanda.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 24)); // NOI18N
        btnvisualizarcomanda.setForeground(new java.awt.Color(255, 255, 255));
        btnvisualizarcomanda.setText("Vizualizar Comandas");
        btnvisualizarcomanda.addActionListener(this::btnvisualizarcomandaActionPerformed);

        btngenerarreporte.setBackground(new java.awt.Color(204, 204, 204));
        btngenerarreporte.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 24)); // NOI18N
        btngenerarreporte.setForeground(new java.awt.Color(255, 255, 255));
        btngenerarreporte.setText("Generar Reporte");
        btngenerarreporte.addActionListener(this::btngenerarreporteActionPerformed);

        btncerrarsesion.setBackground(new java.awt.Color(204, 204, 204));
        btncerrarsesion.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 24)); // NOI18N
        btncerrarsesion.setForeground(new java.awt.Color(255, 255, 255));
        btncerrarsesion.setText("Cerrar Sesión");
        btncerrarsesion.addActionListener(this::btncerrarsesionActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 255, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btngenerarcomanda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(255, 255, 255))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(225, 225, 225)
                        .addComponent(btngenerarreporte, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(275, 275, 275)
                        .addComponent(btncerrarsesion, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addComponent(btnvisualizarcomanda, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addGap(35, 35, 35)
                .addComponent(btngenerarcomanda, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btnvisualizarcomanda, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btngenerarreporte, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(btncerrarsesion, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btngenerarcomandaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngenerarcomandaActionPerformed
                 abrirGenerarComandas();
    }//GEN-LAST:event_btngenerarcomandaActionPerformed

    private void btnvisualizarcomandaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnvisualizarcomandaActionPerformed
        // TODO add your handling code here:
        abrirVisualizarComandas();
    }//GEN-LAST:event_btnvisualizarcomandaActionPerformed

    private void btngenerarreporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngenerarreporteActionPerformed
        // TODO add your handling code here:
        abrirGenerarReporte();
    }//GEN-LAST:event_btngenerarreporteActionPerformed

    private void btncerrarsesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncerrarsesionActionPerformed
        // TODO add your handling code here:
        cerrarSesion();
    }//GEN-LAST:event_btncerrarsesionActionPerformed

private void abrirGenerarComandas() {
    this.setVisible(false);
    new GenerarComandas(this).setVisible(true);
}

private void abrirVisualizarComandas() {
    this.setVisible(false);
    new VisualizarComandas(this).setVisible(true);
}

private void abrirGenerarReporte() {
    this.setVisible(false);
    new GenerarReportes(this).setVisible(true);
}
    private void cerrarSesion() {
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "¿Está seguro que desea cerrar sesión?",
            "Confirmar cierre de sesión",
            JOptionPane.YES_NO_OPTION
        );
        
        if (confirm == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Sesión cerrada exitosamente");
            System.exit(0);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc="Look and feel setting code (optional)">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new MenuPrincipal().setVisible(true);
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btncerrarsesion;
    private javax.swing.JToggleButton btngenerarcomanda;
    private javax.swing.JToggleButton btngenerarreporte;
    private javax.swing.JToggleButton btnvisualizarcomanda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
