package Principal;

import javax.swing.*;
import javax.swing.DefaultListModel;
import java.text.SimpleDateFormat;
import java.awt.*;
import java.util.List;

public class VisualizarComandas extends javax.swing.JFrame {
    
    private DefaultListModel<String> modeloProceso;
    private DefaultListModel<String> modeloListos;
    private JList<String> listaProceso;
    private JList<String> listaListos;
    private SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm");
    
    private MenuPrincipal menuPrincipal;

    public VisualizarComandas(MenuPrincipal menuPrincipal) {
        this.menuPrincipal = menuPrincipal;
        initComponents();
        // NO llamar inicializarComponentes aquí todavía
        setLocationRelativeTo(null);
        // Configurar después de que todos los componentes estén inicializados
        SwingUtilities.invokeLater(this::configurarInterfaz);
    }
    
    public VisualizarComandas() {
        this(null);
    }
    
    private void configurarInterfaz() {
        // 1. Configurar paneles para usar BorderLayout
        jPanel4.setLayout(new BorderLayout());
        jPanel7.setLayout(new BorderLayout());
        jPanel6.setLayout(new BorderLayout());
        
        // 2. Inicializar modelos y listas
        modeloProceso = new DefaultListModel<>();
        modeloListos = new DefaultListModel<>();
        
        listaProceso = new JList<>(modeloProceso);
        listaListos = new JList<>(modeloListos);
        
        // 3. Configurar JScrollPanes
        JScrollPane scrollProceso = new JScrollPane(listaProceso);
        JScrollPane scrollListos = new JScrollPane(listaListos);
        
        // 4. Agregar scrolls a los paneles
        jPanel4.add(scrollProceso, BorderLayout.CENTER);
        jPanel7.add(scrollListos, BorderLayout.CENTER);
        
        // 5. Personalizar apariencia de las listas
        listaProceso.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        listaListos.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        
        listaProceso.setBackground(Color.WHITE);
        listaListos.setBackground(Color.WHITE);
        listaProceso.setSelectionBackground(new Color(209, 182, 255));
        listaListos.setSelectionBackground(new Color(209, 182, 255));
        
        // 6. Configurar etiquetas según el diseño
        jLabel1.setText("PEDIDOS EN PROCESO");
        jLabel2.setText("PEDIDOS LISTO PARA ENTREGAR");
        jLabel3.setText("COMANDAS LISTA PARA ENTREGAR");
        jLabel4.setText("Sistema de seguimiento en tiempo real");
        jLabel5.setText("las comandas aparecen automaticamente cuando se generan");
        jLabel6.setText("PEDIDOS EN PROCESO");
        jLabel8.setText("PEDIDOS LISTOS");
        
        jLabel7.setText("0");
        jLabel9.setText("0");
        
        // 7. Configurar el panel derecho (blanco)
        jPanel6.setBackground(Color.WHITE);
        
        // Crear un panel organizado para el lado derecho
        JPanel panelDerecho = new JPanel(new BorderLayout());
        panelDerecho.setBackground(Color.WHITE);
        
        // Panel superior con texto informativo
        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(new BoxLayout(panelSuperior, BoxLayout.Y_AXIS));
        panelSuperior.setBackground(Color.WHITE);
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        
        // Configurar fuentes de las etiquetas del lado derecho
        jLabel3.setFont(new Font("Arial", Font.BOLD, 20));
        jLabel3.setForeground(new Color(126, 0, 211));
        jLabel3.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        jLabel4.setFont(new Font("Arial", Font.PLAIN, 12));
        jLabel4.setForeground(new Color(126, 0, 211));
        jLabel4.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        jLabel5.setFont(new Font("Arial", Font.PLAIN, 12));
        jLabel5.setForeground(new Color(126, 0, 211));
        jLabel5.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        jLabel2.setFont(new Font("Arial", Font.BOLD, 14));
        jLabel2.setForeground(new Color(126, 0, 211));
        jLabel2.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Agregar componentes al panel superior
        panelSuperior.add(jLabel3);
        panelSuperior.add(Box.createRigidArea(new Dimension(0, 15)));
        panelSuperior.add(jLabel4);
        panelSuperior.add(Box.createRigidArea(new Dimension(0, 5)));
        panelSuperior.add(jLabel5);
        
        // Panel para la lista de pedidos listos
        JPanel panelListaDerecha = new JPanel(new BorderLayout());
        panelListaDerecha.setBackground(Color.WHITE);
        panelListaDerecha.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Título sobre la lista derecha
        JPanel tituloListaDerecha = new JPanel(new FlowLayout(FlowLayout.LEFT));
        tituloListaDerecha.setBackground(Color.WHITE);
        tituloListaDerecha.add(jLabel2);
        
        panelListaDerecha.add(tituloListaDerecha, BorderLayout.NORTH);
        panelListaDerecha.add(jPanel7, BorderLayout.CENTER);
        
        // Organizar el panel derecho
        panelDerecho.add(panelSuperior, BorderLayout.NORTH);
        panelDerecho.add(panelListaDerecha, BorderLayout.CENTER);
        
        // Reemplazar el contenido del jPanel6
        jPanel6.removeAll();
        jPanel6.setLayout(new BorderLayout());
        jPanel6.add(panelDerecho, BorderLayout.CENTER);
        
        // 8. Configurar botones
        btnlisto.setBackground(new Color(0, 200, 0)); // Verde más suave
        btnlisto.setForeground(Color.WHITE);
        btnlisto.setFont(new Font("Arial", Font.BOLD, 14));
        
        btndetalles.setBackground(new Color(100, 100, 255)); // Azul
        btndetalles.setForeground(Color.WHITE);
        btndetalles.setFont(new Font("Arial", Font.PLAIN, 12));
        
        btnactualizar.setBackground(new Color(255, 150, 50)); // Naranja
        btnactualizar.setForeground(Color.WHITE);
        btnactualizar.setFont(new Font("Arial", Font.PLAIN, 12));
        
        btnregresar.setBackground(new Color(200, 50, 200)); // Morado
        btnregresar.setForeground(Color.WHITE);
        btnregresar.setFont(new Font("Arial", Font.PLAIN, 12));
        
        btnBorrarTodas.setBackground(new Color(255, 80, 80)); // Rojo
        btnBorrarTodas.setForeground(Color.WHITE);
        btnBorrarTodas.setFont(new Font("Arial", Font.PLAIN, 12));
        
        // 9. Configurar el panel izquierdo
        jPanel1.setBackground(new Color(147, 112, 219)); // Morado más suave
        jLabel1.setFont(new Font("Arial", Font.BOLD, 14));
        jLabel1.setForeground(Color.WHITE);
        
        // 10. Actualizar listas
        actualizarListas();
        
        // 11. Forzar actualización del layout
        revalidate();
        repaint();
    }
    
    private void cargarComandasDesdeMongoDB() {
        try {
            List<GenerarComandas.ComandaData> comandasMongo = ConexionMongoDB.obtenerTodasComandas();
            
            if (comandasMongo != null && !comandasMongo.isEmpty()) {
                GenerarComandas.todasLasComandas.clear();
                GenerarComandas.todasLasComandas.addAll(comandasMongo);
                System.out.println("✅ " + comandasMongo.size() + " comandas cargadas desde MongoDB");
            }
        } catch (Exception e) {
            System.err.println("⚠️ Error cargando desde MongoDB: " + e.getMessage());
        }
    }
    
    private void actualizarListas() {
        cargarComandasDesdeMongoDB();
        
        if (modeloProceso == null || modeloListos == null) {
            return;
        }
        
        modeloProceso.clear();
        modeloListos.clear();
        
        if (GenerarComandas.todasLasComandas == null) {
            return;
        }
        
        int contProceso = 0;
        int contListos = 0;
        
        for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
            String texto = String.format("#%04d - %s - S/ %.2f - %s", 
                comanda.id, comanda.cliente, comanda.total, comanda.hora);
            
            if ("EN_PROCESO".equals(comanda.estado)) {
                modeloProceso.addElement("⏳ " + texto);
                contProceso++;
            } else if ("LISTO".equals(comanda.estado)) {
                modeloListos.addElement("✅ " + texto);
                contListos++;
            }
        }
        
        jLabel7.setText(String.valueOf(contProceso));
        jLabel9.setText(String.valueOf(contListos));
        
        // Actualizar visualmente
        revalidate();
        repaint();
    }
    
    private void marcarComandaComoLista() {
        int index = listaProceso.getSelectedIndex();
        if (index == -1) {
            JOptionPane.showMessageDialog(this, 
                "Seleccione una comanda en proceso", 
                "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String seleccionado = modeloProceso.getElementAt(index);
        int id = obtenerIdDesdeTexto(seleccionado);
        
        if (id == -1) return;
        
        for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
            if (comanda.id == id && "EN_PROCESO".equals(comanda.estado)) {
                comanda.estado = "LISTO";
                comanda.horaListo = new java.util.Date();
                
                ConexionMongoDB.actualizarEstadoComanda(id, "LISTO");
                
                JOptionPane.showMessageDialog(this, 
                    "✅ Comanda #" + id + " marcada como LISTA\n" +
                    "Hora de completado: " + formatoHora.format(comanda.horaListo),
                    "Comanda Lista", JOptionPane.INFORMATION_MESSAGE);
                
                actualizarListas();
                return;
            }
        }
    }
    
    private void mostrarDetalles() {
        String textoSeleccionado = null;
        
        if (!listaProceso.isSelectionEmpty()) {
            textoSeleccionado = listaProceso.getSelectedValue();
        } else if (!listaListos.isSelectionEmpty()) {
            textoSeleccionado = listaListos.getSelectedValue();
        } else {
            JOptionPane.showMessageDialog(this, 
                "Seleccione una comanda", 
                "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int id = obtenerIdDesdeTexto(textoSeleccionado);
        if (id == -1) return;
        
        for (GenerarComandas.ComandaData comanda : GenerarComandas.todasLasComandas) {
            if (comanda.id == id) {
                mostrarDialogoDetalles(comanda);
                return;
            }
        }
    }
    
    private void mostrarDialogoDetalles(GenerarComandas.ComandaData comanda) {
        StringBuilder detalles = new StringBuilder();
        detalles.append("════════════════════════════════════════\n");
        detalles.append("         DETALLES DE LA COMANDA         \n");
        detalles.append("════════════════════════════════════════\n\n");
        
        detalles.append("📋 N° Comanda: #").append(comanda.id).append("\n");
        detalles.append("👤 Cliente: ").append(comanda.cliente).append("\n");
        detalles.append("📊 Estado: ").append(comanda.estado).append("\n");
        detalles.append("📅 Fecha: ").append(comanda.fecha).append("\n");
        detalles.append("⏰ Hora pedido: ").append(comanda.hora).append("\n");
        
        if (comanda.horaListo != null) {
            detalles.append("✅ Hora completado: ").append(formatoHora.format(comanda.horaListo)).append("\n");
        }
        
        detalles.append("\n🍽️ PRODUCTOS PEDIDOS:\n");
        detalles.append("────────────────────────────────────────\n");
        
        if (comanda.productos != null && !comanda.productos.isEmpty()) {
            for (String producto : comanda.productos) {
                detalles.append("• ").append(producto).append("\n");
            }
        } else {
            detalles.append("Sin productos registrados\n");
        }
        
        detalles.append("\n💰 TOTAL: S/ ").append(String.format("%.2f", comanda.total)).append("\n");
        
        if (comanda.comentarios != null && !comanda.comentarios.isEmpty()) {
            detalles.append("\n💬 COMENTARIOS:\n");
            detalles.append(comanda.comentarios).append("\n");
        }
        
        detalles.append("\n════════════════════════════════════════\n");
        
        JTextArea area = new JTextArea(detalles.toString());
        area.setFont(new Font("Monospaced", Font.PLAIN, 12));
        area.setEditable(false);
        
        JScrollPane scroll = new JScrollPane(area);
        scroll.setPreferredSize(new Dimension(500, 400));
        
        JOptionPane.showMessageDialog(this, scroll, 
            "Detalles Comanda #" + comanda.id, JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void regresarAlMenu() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "¿Regresar al menú principal?",
            "Confirmar Regreso",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            this.dispose();
            if (menuPrincipal != null) {
                menuPrincipal.setVisible(true);
                menuPrincipal.setLocationRelativeTo(null);
            }
        }
    }
    
    private int obtenerIdDesdeTexto(String texto) {
        try {
            if (texto == null) return -1;
            
            int inicio = texto.indexOf('#') + 1;
            if (inicio <= 0) return -1;
            
            int fin = texto.indexOf(' ', inicio);
            if (fin == -1) fin = texto.indexOf('-', inicio);
            if (fin == -1) fin = texto.length();
            
            String idStr = texto.substring(inicio, fin).trim();
            return Integer.parseInt(idStr);
        } catch (Exception e) {
            return -1;
        }
    }
    
    private void borrarTodasLasComandas() {
        String contraseña = JOptionPane.showInputDialog(
            this,
            "🔐 Ingrese contraseña de administrador para borrar TODAS las comandas:",
            "Autenticación Requerida",
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (contraseña == null || contraseña.trim().isEmpty()) {
            return;
        }
        
        boolean contraseñaCorrecta = ConexionMongoDB.verificarContraseñaAdmin(contraseña);
        
        if (!contraseñaCorrecta) {
            JOptionPane.showMessageDialog(this,
                "❌ Contraseña incorrecta\nNo tiene permisos para esta acción.",
                "Acceso Denegado",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "⚠️ ¿Está seguro de borrar TODAS las comandas?\nEsta acción no se puede deshacer.",
            "Confirmar Borrado",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        
        try {
            boolean exito = ConexionMongoDB.borrarTodasLasComandas();
            
            if (exito) {
                if (GenerarComandas.todasLasComandas != null) {
                    GenerarComandas.todasLasComandas.clear();
                }
                
                actualizarListas();
                
                JOptionPane.showMessageDialog(this,
                    "✅ Todas las comandas han sido borradas",
                    "Borrado Exitoso",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Error al borrar las comandas",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "❌ Error: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane2 = new javax.swing.JSplitPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        btnlisto = new javax.swing.JButton();
        btndetalles = new javax.swing.JButton();
        btnactualizar = new javax.swing.JButton();
        btnregresar = new javax.swing.JButton();
        btnBorrarTodas = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jSplitPane2.setDividerLocation(600);
        jSplitPane2.setDividerSize(3);

        jPanel1.setBackground(new java.awt.Color(126, 0, 211));
        jPanel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(15, 15, 15, 15));

        jPanel2.setBackground(new java.awt.Color(253, 174, 179));
        jPanel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 15, 0));

        jLabel7.setFont(new java.awt.Font("Arial", 1, 48)); // NOI18N
        jLabel7.setText("0");

        jLabel6.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 18)); // NOI18N
        jLabel6.setText("PEDIDOS EN PROCESO");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel6)
                .addContainerGap(38, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(102, 102, 102))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(196, 246, 196));
        jPanel5.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 15, 0));

        jLabel8.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 18)); // NOI18N
        jLabel8.setText("PEDIDOS LISTOS ");

        jLabel9.setFont(new java.awt.Font("Arial", 1, 48)); // NOI18N
        jLabel9.setText("0");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(69, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(55, 55, 55))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(89, 89, 89))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addGap(44, 44, 44))
        );

        jLabel1.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("PEDIDOS EN PROCESO ");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 232, Short.MAX_VALUE)
        );

        btnlisto.setBackground(new java.awt.Color(0, 255, 51));
        btnlisto.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        btnlisto.setForeground(new java.awt.Color(255, 255, 255));
        btnlisto.setText("LISTO");
        btnlisto.addActionListener(this::btnlistoActionPerformed);

        btndetalles.setBackground(new java.awt.Color(153, 153, 255));
        btndetalles.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 12)); // NOI18N
        btndetalles.setForeground(new java.awt.Color(255, 255, 255));
        btndetalles.setText("VER DETALLES");
        btndetalles.addActionListener(this::btndetallesActionPerformed);

        btnactualizar.setBackground(new java.awt.Color(255, 182, 65));
        btnactualizar.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 12)); // NOI18N
        btnactualizar.setForeground(new java.awt.Color(255, 255, 255));
        btnactualizar.setText("ACTUALIZAR");
        btnactualizar.addActionListener(this::btnactualizarActionPerformed);

        btnregresar.setBackground(new java.awt.Color(255, 102, 255));
        btnregresar.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 12)); // NOI18N
        btnregresar.setForeground(new java.awt.Color(255, 255, 255));
        btnregresar.setText("REGRESAR");
        btnregresar.addActionListener(this::btnregresarActionPerformed);

        btnBorrarTodas.setBackground(new java.awt.Color(255, 102, 102));
        btnBorrarTodas.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 12)); // NOI18N
        btnBorrarTodas.setForeground(new java.awt.Color(255, 255, 255));
        btnBorrarTodas.setText("LIMPIAR");
        btnBorrarTodas.addActionListener(this::btnBorrarTodasActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnlisto, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btndetalles)
                                .addGap(26, 26, 26)
                                .addComponent(btnactualizar)
                                .addGap(18, 18, 18)
                                .addComponent(btnregresar)
                                .addGap(18, 18, 18)
                                .addComponent(btnBorrarTodas)
                                .addGap(0, 15, Short.MAX_VALUE))
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(43, 43, 43)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(179, 179, 179)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnactualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnlisto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btndetalles, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBorrarTodas, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnregresar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jSplitPane2.setLeftComponent(jPanel1);

        jPanel6.setBackground(new java.awt.Color(153, 255, 204));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 466, Short.MAX_VALUE)
        );

        jLabel2.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(126, 0, 211));
        jLabel2.setText("PEDIDOS LISTO PARA ENTREGAR");

        jLabel3.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(126, 0, 211));
        jLabel3.setText("COMANDAS LISTA PARA ENTREGAR");

        jLabel4.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(126, 0, 211));
        jLabel4.setText("Sistema de seguimiento en tiempo real las comandas");

        jLabel5.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(126, 0, 211));
        jLabel5.setText("aparecen automaticamente cuando se generan");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 514, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 136, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        jSplitPane2.setRightComponent(jPanel6);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane2)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane2)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnlistoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlistoActionPerformed
        // TODO add your handling code here:
        marcarComandaComoLista(); 
    }//GEN-LAST:event_btnlistoActionPerformed

    private void btnactualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnactualizarActionPerformed
        // TODO add your handling code here:
        actualizarListas();
    }//GEN-LAST:event_btnactualizarActionPerformed

    private void btndetallesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndetallesActionPerformed
        mostrarDetalles();
    }//GEN-LAST:event_btndetallesActionPerformed

    private void btnregresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnregresarActionPerformed
        // TODO add your handling code here:
        regresarAlMenu();
    }//GEN-LAST:event_btnregresarActionPerformed

    private void btnBorrarTodasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarTodasActionPerformed
        // TODO add your handling code here:
        borrarTodasLasComandas();
    }//GEN-LAST:event_btnBorrarTodasActionPerformed

    public static void main(String args[]) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        java.awt.EventQueue.invokeLater(() -> {
            new VisualizarComandas().setVisible(true);
        });
    }
        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBorrarTodas;
    private javax.swing.JButton btnactualizar;
    private javax.swing.JButton btndetalles;
    private javax.swing.JButton btnlisto;
    private javax.swing.JButton btnregresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JSplitPane jSplitPane2;
    // End of variables declaration//GEN-END:variables
}
