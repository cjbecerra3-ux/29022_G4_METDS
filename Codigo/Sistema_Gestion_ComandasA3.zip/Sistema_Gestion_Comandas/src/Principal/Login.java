package Principal;

import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class Login extends javax.swing.JFrame {
    
    // ⭐⭐ CONFIGURAR LOGS ANTES DE CUALQUIER COSA ⭐⭐
    static {
        // SOLUCIÓN DEFINITIVA: Configurar logging ANTES de que se cargue MongoDB
        System.setProperty("java.util.logging.config.file", "");
        
        // Desactivar TODOS los logs de MongoDB
        System.setProperty("org.mongodb.driver.cluster", "WARN");
        System.setProperty("org.mongodb.driver.client", "WARN");
        System.setProperty("org.mongodb.driver.connection", "WARN");
        System.setProperty("org.mongodb.driver.operation", "WARN");
        System.setProperty("DEBUG.MONGO", "false");
        System.setProperty("DB.TRACE", "false");
        
        // Configurar niveles de logging
        java.util.logging.Logger rootLogger = java.util.logging.Logger.getLogger("");
        rootLogger.setLevel(java.util.logging.Level.WARNING);
        
        // Específicamente para MongoDB
        java.util.logging.Logger mongoLogger = java.util.logging.Logger.getLogger("org.mongodb.driver");
        mongoLogger.setLevel(java.util.logging.Level.SEVERE);
        mongoLogger.setUseParentHandlers(false);
        
        // También para paquetes relacionados
        java.util.logging.Logger.getLogger("com.mongodb").setLevel(java.util.logging.Level.SEVERE);
    }
    
    // Configuración
    private static final int MAX_INTENTOS = 3;
    private static final int TIEMPO_BLOQUEO_SEGUNDOS = 30;
    
    // Variables de sesión
    public static String usuarioSesion = "";
    public static String nombreSesion = "";
    public static String rolSesion = "";
    
    // Conexión MongoDB
    private static final String MONGO_URI = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "restaurante_braymar";

    public Login() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        configurarColores();
    }
    
    private void configurarColores() {
        btnacceder.setBackground(new Color(121, 0, 209));
        btnacceder.setForeground(Color.WHITE);
        btnacceder.setFocusPainted(false);
        btnacceder.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btnolvidarcontra.setForeground(new Color(121, 0, 209));
        btnolvidarcontra.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnolvidarcontra.setBorderPainted(false);
        btnolvidarcontra.setContentAreaFilled(false);
        
        txtusuario.setBorder(BorderFactory.createLineBorder(new Color(121, 0, 209), 1));
        txtcontraseña.setBorder(BorderFactory.createLineBorder(new Color(121, 0, 209), 1));
        
        txtusuario.setToolTipText("Ingrese su nombre de usuario");
        txtcontraseña.setToolTipText("Ingrese su contraseña");
    }
    
    private boolean validarCredenciales(String usuario, String contrasena) {
        MongoClient mongoClient = null;
        try {
            // Conectar a MongoDB (sin logs visibles)
            mongoClient = MongoClients.create(MONGO_URI);
            MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
            MongoCollection<Document> usuarios = database.getCollection("usuarios");
            
            // Buscar usuario
            Document query = new Document("usuario", usuario)
                .append("activo", true);
            
            Document usuarioDoc = usuarios.find(query).first();
            
            if (usuarioDoc == null) {
                mostrarIntentoFallido(MAX_INTENTOS - 1);
                return false;
            }
            
            // Verificar si está bloqueado
            Boolean bloqueado = usuarioDoc.getBoolean("bloqueado");
            if (bloqueado != null && bloqueado) {
                Long fechaBloqueo = usuarioDoc.getLong("fechaBloqueo");
                if (fechaBloqueo != null) {
                    long tiempoActual = System.currentTimeMillis();
                    long segundosTranscurridos = (tiempoActual - fechaBloqueo) / 1000;
                    
                    if (segundosTranscurridos < TIEMPO_BLOQUEO_SEGUNDOS) {
                        int segundosRestantes = TIEMPO_BLOQUEO_SEGUNDOS - (int) segundosTranscurridos;
                        mostrarErrorBloqueo(usuario, segundosRestantes);
                        return false;
                    } else {
                        // Desbloquear usuario
                        Document update = new Document("$set",
                            new Document("bloqueado", false)
                                .append("intentosFallidos", 0));
                        usuarios.updateOne(query, update);
                    }
                }
            }
            
            // Verificar contraseña
            String contrasenaGuardada = usuarioDoc.getString("contrasena");
            
            if (contrasenaGuardada != null && contrasenaGuardada.equals(contrasena)) {
                // Login exitoso
                Document update = new Document("$set",
                    new Document("intentosFallidos", 0)
                        .append("ultimoAcceso", System.currentTimeMillis()));
                usuarios.updateOne(query, update);
                
                // Guardar datos de sesión
                usuarioSesion = usuario;
                nombreSesion = usuarioDoc.getString("nombre");
                rolSesion = usuarioDoc.getString("rol");
                
                return true;
            } else {
                // Login fallido
                int intentosActuales = usuarioDoc.getInteger("intentosFallidos", 0);
                int nuevosIntentos = intentosActuales + 1;
                
                Document update;
                if (nuevosIntentos >= MAX_INTENTOS) {
                    // Bloquear usuario
                    update = new Document("$set",
                        new Document("intentosFallidos", nuevosIntentos)
                            .append("bloqueado", true)
                            .append("fechaBloqueo", System.currentTimeMillis()));
                    usuarios.updateOne(query, update);
                    
                    mostrarBloqueoUsuario(usuario);
                } else {
                    update = new Document("$set",
                        new Document("intentosFallidos", nuevosIntentos));
                    usuarios.updateOne(query, update);
                    
                    int intentosRestantes = MAX_INTENTOS - nuevosIntentos;
                    mostrarIntentoFallido(intentosRestantes);
                }
                return false;
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "❌ Error de conexión con la base de datos",
                "Error del Sistema",
                JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            if (mongoClient != null) {
                mongoClient.close();
            }
        }
    }
    
    private void mostrarIntentoFallido(int intentosRestantes) {
        JOptionPane.showMessageDialog(this,
            "❌ Usuario o contraseña incorrectos\n" +
            "Intentos restantes: " + intentosRestantes,
            "Error de autenticación",
            JOptionPane.WARNING_MESSAGE);
        
        txtcontraseña.setText("");
        txtcontraseña.requestFocus();
    }
    
    private void mostrarBloqueoUsuario(String usuario) {
        JOptionPane.showMessageDialog(this,
            "🔒 Usuario bloqueado por " + TIEMPO_BLOQUEO_SEGUNDOS + " segundos\n" +
            "Usuario: " + usuario + "\n" +
            "Razón: Demasiados intentos fallidos",
            "Usuario Bloqueado",
            JOptionPane.ERROR_MESSAGE);
        
        txtusuario.setText("");
        txtcontraseña.setText("");
        txtusuario.requestFocus();
        
        btnacceder.setEnabled(false);
        
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> {
                    btnacceder.setEnabled(true);
                    JOptionPane.showMessageDialog(Login.this,
                        "✅ Usuario desbloqueado\n" +
                        "Puede intentar nuevamente",
                        "Usuario Desbloqueado",
                        JOptionPane.INFORMATION_MESSAGE);
                });
            }
        }, TIEMPO_BLOQUEO_SEGUNDOS * 1000);
    }
    
    private void mostrarErrorBloqueo(String usuario, int segundosRestantes) {
        JOptionPane.showMessageDialog(this,
            "⏳ Usuario temporalmente bloqueado\n" +
            "Usuario: " + usuario + "\n" +
            "Tiempo restante: " + segundosRestantes + " segundos",
            "Acceso Bloqueado",
            JOptionPane.ERROR_MESSAGE);
        
        txtusuario.setText("");
        txtcontraseña.setText("");
        txtusuario.requestFocus();
    }
    
    private void realizarLogin() {
        String usuario = txtusuario.getText().trim();
        String contrasena = new String(txtcontraseña.getPassword()).trim();
        
        if (usuario.isEmpty() || contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "⚠️ Por favor, complete todos los campos",
                "Campos incompletos",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (validarCredenciales(usuario, contrasena)) {
            // Obtener nombre real para mostrar
            String nombreMostrar = nombreSesion.isEmpty() ? usuario : nombreSesion;
            
            JOptionPane.showMessageDialog(this,
                "✅ ¡Bienvenido, " + nombreMostrar + "!",
                "Acceso concedido",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Abrir menú principal
            MenuPrincipal MenuInterfaz = new MenuPrincipal();
            MenuInterfaz.setLocationRelativeTo(null);
            MenuInterfaz.setVisible(true);
            this.dispose();
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtusuario = new javax.swing.JTextField();
        txtcontraseña = new javax.swing.JPasswordField();
        btnacceder = new javax.swing.JButton();
        btnolvidarcontra = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));

        jPanel3.setBackground(new java.awt.Color(126, 0, 211));
        jPanel3.setPreferredSize(new java.awt.Dimension(400, 500));
        jPanel3.setLayout(null);

        jLabel1.setBackground(new java.awt.Color(119, 0, 238));
        jLabel1.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(121, 0, 209));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("INICIAR SESIÓN");

        jLabel2.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(121, 0, 209));
        jLabel2.setText("USUARIO");

        jLabel3.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(121, 0, 209));
        jLabel3.setText("CONTRASEÑA");

        jLabel4.setText("BRAYMAR RESTAURANTE MARISQUERIA");

        txtusuario.addActionListener(this::txtusuarioActionPerformed);

        txtcontraseña.addActionListener(this::txtcontraseñaActionPerformed);

        btnacceder.setBackground(new java.awt.Color(121, 0, 209));
        btnacceder.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        btnacceder.setForeground(new java.awt.Color(255, 255, 255));
        btnacceder.setText("ACCEDER");
        btnacceder.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        btnacceder.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnacceder.addActionListener(this::btnaccederActionPerformed);

        btnolvidarcontra.setForeground(new java.awt.Color(121, 0, 209));
        btnolvidarcontra.setText("¿Olvidaste tu contraseña?");
        btnolvidarcontra.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        btnolvidarcontra.addActionListener(this::btnolvidarcontraActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel4)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3)
                                .addComponent(txtusuario)
                                .addComponent(txtcontraseña, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE))
                            .addComponent(jLabel1))
                        .addContainerGap(35, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnacceder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnolvidarcontra, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE))
                        .addGap(50, 50, 50))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(44, 44, 44)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(txtusuario, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(txtcontraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(btnacceder, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnolvidarcontra)
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtusuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtusuarioActionPerformed
        // TODO add your handling code here:
        txtcontraseña.requestFocus();
    }//GEN-LAST:event_txtusuarioActionPerformed

    private void btnaccederActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaccederActionPerformed
        // TODO add your handling code here:sfduudhfouiaebhfoiqwboirg
           realizarLogin();
    }//GEN-LAST:event_btnaccederActionPerformed

    private void btnolvidarcontraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnolvidarcontraActionPerformed
        VerificacionID ventanaVerificacion = new VerificacionID();
        ventanaVerificacion.setLocationRelativeTo(null);
        ventanaVerificacion.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnolvidarcontraActionPerformed

    private void txtcontraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcontraseñaActionPerformed
        // TODO add your handling code here:
        realizarLogin();
    }//GEN-LAST:event_txtcontraseñaActionPerformed
    
    
    private void txtusuarioKeyPressed(java.awt.event.KeyEvent evt) {                                      
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            txtcontraseña.requestFocus();
        }
    }                                     
    
    private void txtcontraseñaKeyPressed(java.awt.event.KeyEvent evt) {                                         
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            realizarLogin();
        }
    }                                        

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // ⭐⭐ SOLUCIÓN EXTREMA: REDIRIGIR TODA LA SALIDA ⭐⭐
        try {
            // Guardar referencia original
            java.io.PrintStream originalOut = System.out;
            java.io.PrintStream originalErr = System.err;
            
            // Crear un output stream que filtre MongoDB
            java.io.PrintStream filteredStream = new java.io.PrintStream(
                new java.io.OutputStream() {
                    @Override
                    public void write(int b) {
                        // No hacer nada - silenciar completamente
                    }
                }
            );
            
            // Redirigir ANTES de cualquier otra cosa
            System.setOut(filteredStream);
            System.setErr(filteredStream);
            
            // Configurar logging a OFF
            java.util.logging.LogManager.getLogManager().reset();
            
        } catch (Exception e) {
            // Ignorar errores de redirección
        }
        
        /* Set the Nimbus look and feel */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Login().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnacceder;
    private javax.swing.JButton btnolvidarcontra;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPasswordField txtcontraseña;
    private javax.swing.JTextField txtusuario;
    // End of variables declaration//GEN-END:variables
}
